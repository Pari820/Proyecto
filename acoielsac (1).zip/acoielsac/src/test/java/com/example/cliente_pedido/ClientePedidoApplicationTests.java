package com.example.cliente_pedido;

import org.junit.jupiter.api.Test;

class ClientePedidoApplicationTests {
    @Test
    void contextLoads() {
    }
}
