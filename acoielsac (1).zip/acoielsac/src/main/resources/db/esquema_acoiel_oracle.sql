/* =========================================================
   ESQUEMA FÍSICO - SISTEMA ACOIEL SAC
   Base de datos: Oracle
   ========================================================= */

/* =========================
   1. PERSONA Y CLIENTE
   ========================= */

CREATE TABLE PERSONA (
    id_persona NUMBER GENERATED ALWAYS AS IDENTITY,
    tipo_documento VARCHAR2(20) NOT NULL,
    nro_documento VARCHAR2(20) NOT NULL,
    nombres VARCHAR2(100) NOT NULL,
    apellidos VARCHAR2(100),
    celular VARCHAR2(20),
    correo VARCHAR2(120),
    CONSTRAINT pk_persona PRIMARY KEY (id_persona),
    CONSTRAINT uq_persona_documento UNIQUE (tipo_documento, nro_documento)
);

CREATE TABLE CLIENTE (
    id_cliente NUMBER GENERATED ALWAYS AS IDENTITY,
    ruc VARCHAR2(20) NOT NULL,
    razon_social VARCHAR2(150) NOT NULL,
    direccion VARCHAR2(200),
    telefono VARCHAR2(20),
    estado_cliente VARCHAR2(20) DEFAULT 'ACTIVO' NOT NULL,
    CONSTRAINT pk_cliente PRIMARY KEY (id_cliente),
    CONSTRAINT uq_cliente_ruc UNIQUE (ruc),
    CONSTRAINT chk_cliente_estado CHECK (estado_cliente IN ('ACTIVO', 'INACTIVO'))
);

CREATE TABLE CARGO (
    id_cargo NUMBER GENERATED ALWAYS AS IDENTITY,
    nombre_cargo VARCHAR2(80) NOT NULL,
    CONSTRAINT pk_cargo PRIMARY KEY (id_cargo),
    CONSTRAINT uq_cargo_nombre UNIQUE (nombre_cargo)
);

CREATE TABLE ESPECIALIDAD (
    id_especialidad NUMBER GENERATED ALWAYS AS IDENTITY,
    nombre_especialidad VARCHAR2(100) NOT NULL,
    descripcion VARCHAR2(250),
    CONSTRAINT pk_especialidad PRIMARY KEY (id_especialidad),
    CONSTRAINT uq_especialidad_nombre UNIQUE (nombre_especialidad)
);

CREATE TABLE EMPLEADO (
    id_persona NUMBER NOT NULL,
    codigo_empleado VARCHAR2(30),
    fecha_ingreso DATE,
    estado_empleado VARCHAR2(20) DEFAULT 'ACTIVO' NOT NULL,
    id_cargo NUMBER NOT NULL,
    id_especialidad NUMBER,
    CONSTRAINT pk_empleado PRIMARY KEY (id_persona),
    CONSTRAINT fk_empleado_persona FOREIGN KEY (id_persona) REFERENCES PERSONA(id_persona),
    CONSTRAINT fk_empleado_cargo FOREIGN KEY (id_cargo) REFERENCES CARGO(id_cargo),
    CONSTRAINT fk_empleado_especialidad FOREIGN KEY (id_especialidad) REFERENCES ESPECIALIDAD(id_especialidad),
    CONSTRAINT uq_empleado_codigo UNIQUE (codigo_empleado),
    CONSTRAINT chk_empleado_estado CHECK (estado_empleado IN ('ACTIVO', 'INACTIVO'))
);

CREATE TABLE CONTACTO_CLIENTE (
    id_persona NUMBER NOT NULL,
    id_cliente NUMBER NOT NULL,
    cargo_contacto VARCHAR2(100),
    CONSTRAINT pk_contacto_cliente PRIMARY KEY (id_persona),
    CONSTRAINT fk_contacto_persona FOREIGN KEY (id_persona) REFERENCES PERSONA(id_persona),
    CONSTRAINT fk_contacto_cliente FOREIGN KEY (id_cliente) REFERENCES CLIENTE(id_cliente)
);

/* =========================
   2. SEGURIDAD DEL SISTEMA
   ========================= */

CREATE TABLE USUARIO (
    id_usuario NUMBER GENERATED ALWAYS AS IDENTITY,
    id_persona NUMBER NOT NULL,
    nombre_usuario VARCHAR2(80) NOT NULL,
    contrasena VARCHAR2(255) NOT NULL,
    estado_usuario VARCHAR2(20) DEFAULT 'ACTIVO' NOT NULL,
    CONSTRAINT pk_usuario PRIMARY KEY (id_usuario),
    CONSTRAINT fk_usuario_persona FOREIGN KEY (id_persona) REFERENCES PERSONA(id_persona),
    CONSTRAINT uq_usuario_nombre UNIQUE (nombre_usuario),
    CONSTRAINT uq_usuario_persona UNIQUE (id_persona),
    CONSTRAINT chk_usuario_estado CHECK (estado_usuario IN ('ACTIVO', 'INACTIVO'))
);

CREATE TABLE ROL (
    id_rol NUMBER GENERATED ALWAYS AS IDENTITY,
    nombre_rol VARCHAR2(80) NOT NULL,
    descripcion VARCHAR2(250),
    CONSTRAINT pk_rol PRIMARY KEY (id_rol),
    CONSTRAINT uq_rol_nombre UNIQUE (nombre_rol)
);

CREATE TABLE ACCESO (
    id_acceso NUMBER GENERATED ALWAYS AS IDENTITY,
    nombre_modulo VARCHAR2(100) NOT NULL,
    descripcion_acceso VARCHAR2(250),
    CONSTRAINT pk_acceso PRIMARY KEY (id_acceso),
    CONSTRAINT uq_acceso_modulo UNIQUE (nombre_modulo)
);

CREATE TABLE USUARIO_ROL (
    id_usuario_rol NUMBER GENERATED ALWAYS AS IDENTITY,
    id_usuario NUMBER NOT NULL,
    id_rol NUMBER NOT NULL,
    fecha_asignacion DATE DEFAULT SYSDATE NOT NULL,
    estado VARCHAR2(20) DEFAULT 'ACTIVO' NOT NULL,
    CONSTRAINT pk_usuario_rol PRIMARY KEY (id_usuario_rol),
    CONSTRAINT fk_usuario_rol_usuario FOREIGN KEY (id_usuario) REFERENCES USUARIO(id_usuario),
    CONSTRAINT fk_usuario_rol_rol FOREIGN KEY (id_rol) REFERENCES ROL(id_rol),
    CONSTRAINT uq_usuario_rol UNIQUE (id_usuario, id_rol),
    CONSTRAINT chk_usuario_rol_estado CHECK (estado IN ('ACTIVO', 'INACTIVO'))
);

CREATE TABLE ROL_ACCESO (
    id_rol_acceso NUMBER GENERATED ALWAYS AS IDENTITY,
    id_rol NUMBER NOT NULL,
    id_acceso NUMBER NOT NULL,
    permiso_crear CHAR(1) DEFAULT 'N' NOT NULL,
    permiso_leer CHAR(1) DEFAULT 'S' NOT NULL,
    permiso_actualizar CHAR(1) DEFAULT 'N' NOT NULL,
    permiso_eliminar CHAR(1) DEFAULT 'N' NOT NULL,
    CONSTRAINT pk_rol_acceso PRIMARY KEY (id_rol_acceso),
    CONSTRAINT fk_rol_acceso_rol FOREIGN KEY (id_rol) REFERENCES ROL(id_rol),
    CONSTRAINT fk_rol_acceso_acceso FOREIGN KEY (id_acceso) REFERENCES ACCESO(id_acceso),
    CONSTRAINT uq_rol_acceso UNIQUE (id_rol, id_acceso),
    CONSTRAINT chk_permiso_crear CHECK (permiso_crear IN ('S', 'N')),
    CONSTRAINT chk_permiso_leer CHECK (permiso_leer IN ('S', 'N')),
    CONSTRAINT chk_permiso_actualizar CHECK (permiso_actualizar IN ('S', 'N')),
    CONSTRAINT chk_permiso_eliminar CHECK (permiso_eliminar IN ('S', 'N'))
);

CREATE TABLE USO_SISTEMA (
    id_uso NUMBER GENERATED ALWAYS AS IDENTITY,
    id_usuario NUMBER NOT NULL,
    fecha_hora TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    accion_realizada VARCHAR2(150) NOT NULL,
    modulo VARCHAR2(100),
    descripcion VARCHAR2(300),
    CONSTRAINT pk_uso_sistema PRIMARY KEY (id_uso),
    CONSTRAINT fk_uso_usuario FOREIGN KEY (id_usuario) REFERENCES USUARIO(id_usuario)
);

/* =========================
   3. GESTIÓN COMERCIAL
   ========================= */

CREATE TABLE TIPO_SERVICIO (
    id_tipo_servicio NUMBER GENERATED ALWAYS AS IDENTITY,
    nombre_tipo_servicio VARCHAR2(120) NOT NULL,
    descripcion VARCHAR2(300),
    estado VARCHAR2(20) DEFAULT 'ACTIVO' NOT NULL,
    CONSTRAINT pk_tipo_servicio PRIMARY KEY (id_tipo_servicio),
    CONSTRAINT uq_tipo_servicio_nombre UNIQUE (nombre_tipo_servicio),
    CONSTRAINT chk_tipo_servicio_estado CHECK (estado IN ('ACTIVO', 'INACTIVO'))
);

CREATE TABLE SOLICITUD_SERVICIO (
    id_solicitud NUMBER GENERATED ALWAYS AS IDENTITY,
    id_cliente NUMBER NOT NULL,
    id_tipo_servicio NUMBER NOT NULL,
    fecha_recepcion DATE DEFAULT SYSDATE NOT NULL,
    descripcion_trabajo VARCHAR2(500) NOT NULL,
    observaciones_iniciales VARCHAR2(500),
    estado_solicitud VARCHAR2(30) DEFAULT 'PENDIENTE' NOT NULL,
    CONSTRAINT pk_solicitud PRIMARY KEY (id_solicitud),
    CONSTRAINT fk_solicitud_cliente FOREIGN KEY (id_cliente) REFERENCES CLIENTE(id_cliente),
    CONSTRAINT fk_solicitud_tipo_servicio FOREIGN KEY (id_tipo_servicio) REFERENCES TIPO_SERVICIO(id_tipo_servicio),
    CONSTRAINT chk_solicitud_estado CHECK (
        estado_solicitud IN ('PENDIENTE', 'COTIZADA', 'ACEPTADA', 'RECHAZADA', 'ASIGNADA', 'PROGRAMADA', 'ATENDIDA', 'CANCELADA')
    )
);

CREATE TABLE COTIZACION (
    id_cotizacion NUMBER GENERATED ALWAYS AS IDENTITY,
    id_solicitud NUMBER NOT NULL,
    fecha_cotizacion DATE DEFAULT SYSDATE NOT NULL,
    descripcion_trabajo VARCHAR2(500),
    monto_estimado NUMBER(12,2) NOT NULL,
    observaciones VARCHAR2(500),
    estado_cotizacion VARCHAR2(30) DEFAULT 'EMITIDA' NOT NULL,
    CONSTRAINT pk_cotizacion PRIMARY KEY (id_cotizacion),
    CONSTRAINT fk_cotizacion_solicitud FOREIGN KEY (id_solicitud) REFERENCES SOLICITUD_SERVICIO(id_solicitud),
    CONSTRAINT chk_cotizacion_monto CHECK (monto_estimado >= 0),
    CONSTRAINT chk_cotizacion_estado CHECK (
        estado_cotizacion IN ('EMITIDA', 'MODIFICADA', 'ACEPTADA', 'RECHAZADA')
    )
);

CREATE TABLE ORDEN_COMPRA (
    id_orden_compra NUMBER GENERATED ALWAYS AS IDENTITY,
    id_cotizacion NUMBER NOT NULL,
    numero_oc VARCHAR2(50) NOT NULL,
    fecha_emision DATE NOT NULL,
    monto_total NUMBER(12,2) NOT NULL,
    archivo_pdf VARCHAR2(300),
    CONSTRAINT pk_orden_compra PRIMARY KEY (id_orden_compra),
    CONSTRAINT fk_oc_cotizacion FOREIGN KEY (id_cotizacion) REFERENCES COTIZACION(id_cotizacion),
    CONSTRAINT uq_oc_numero UNIQUE (numero_oc),
    CONSTRAINT uq_oc_cotizacion UNIQUE (id_cotizacion),
    CONSTRAINT chk_oc_monto CHECK (monto_total >= 0)
);

/* =========================
   4. PLANIFICACIÓN DEL SERVICIO
   ========================= */

CREATE TABLE ORDEN_TRABAJO (
    id_orden_trabajo NUMBER GENERATED ALWAYS AS IDENTITY,
    id_orden_compra NUMBER NOT NULL,
    id_supervisor NUMBER NOT NULL,
    numero_ot VARCHAR2(50) NOT NULL,
    fecha_programada DATE,
    hora_programada VARCHAR2(10),
    lugar_ejecucion VARCHAR2(250),
    croquis VARCHAR2(300),
    estado_ot VARCHAR2(30) DEFAULT 'ASIGNADA' NOT NULL,
    CONSTRAINT pk_orden_trabajo PRIMARY KEY (id_orden_trabajo),
    CONSTRAINT fk_ot_oc FOREIGN KEY (id_orden_compra) REFERENCES ORDEN_COMPRA(id_orden_compra),
    CONSTRAINT fk_ot_supervisor FOREIGN KEY (id_supervisor) REFERENCES EMPLEADO(id_persona),
    CONSTRAINT uq_ot_numero UNIQUE (numero_ot),
    CONSTRAINT uq_ot_oc UNIQUE (id_orden_compra),
    CONSTRAINT chk_ot_estado CHECK (estado_ot IN ('ASIGNADA', 'PROGRAMADA', 'EJECUTADA', 'CANCELADA'))
);

CREATE TABLE ASIGNACION_PERSONAL (
    id_asignacion NUMBER GENERATED ALWAYS AS IDENTITY,
    id_orden_trabajo NUMBER NOT NULL,
    id_empleado NUMBER NOT NULL,
    fecha_asignacion DATE DEFAULT SYSDATE NOT NULL,
    rol_en_servicio VARCHAR2(50) NOT NULL,
    CONSTRAINT pk_asignacion_personal PRIMARY KEY (id_asignacion),
    CONSTRAINT fk_asignacion_ot FOREIGN KEY (id_orden_trabajo) REFERENCES ORDEN_TRABAJO(id_orden_trabajo),
    CONSTRAINT fk_asignacion_empleado FOREIGN KEY (id_empleado) REFERENCES EMPLEADO(id_persona),
    CONSTRAINT chk_rol_servicio CHECK (rol_en_servicio IN ('TECNICO', 'PERSONAL DE APOYO', 'SSOMA')),
    CONSTRAINT uq_asignacion_personal UNIQUE (id_orden_trabajo, id_empleado, rol_en_servicio)
);

CREATE TABLE PROCEDIMIENTO_TRABAJO (
    id_procedimiento NUMBER GENERATED ALWAYS AS IDENTITY,
    id_orden_trabajo NUMBER NOT NULL,
    fecha_registro DATE DEFAULT SYSDATE NOT NULL,
    archivo_procedimiento VARCHAR2(300),
    observaciones VARCHAR2(500),
    estado_aprobacion_cliente VARCHAR2(30) DEFAULT 'PENDIENTE' NOT NULL,
    CONSTRAINT pk_procedimiento PRIMARY KEY (id_procedimiento),
    CONSTRAINT fk_procedimiento_ot FOREIGN KEY (id_orden_trabajo) REFERENCES ORDEN_TRABAJO(id_orden_trabajo),
    CONSTRAINT uq_procedimiento_ot UNIQUE (id_orden_trabajo),
    CONSTRAINT chk_proc_estado CHECK (estado_aprobacion_cliente IN ('PENDIENTE', 'APROBADO', 'RECHAZADO'))
);

CREATE TABLE IPER (
    id_iper NUMBER GENERATED ALWAYS AS IDENTITY,
    id_orden_trabajo NUMBER NOT NULL,
    fecha_registro DATE DEFAULT SYSDATE NOT NULL,
    archivo_iper VARCHAR2(300),
    observaciones VARCHAR2(500),
    estado_aprobacion_cliente VARCHAR2(30) DEFAULT 'PENDIENTE' NOT NULL,
    CONSTRAINT pk_iper PRIMARY KEY (id_iper),
    CONSTRAINT fk_iper_ot FOREIGN KEY (id_orden_trabajo) REFERENCES ORDEN_TRABAJO(id_orden_trabajo),
    CONSTRAINT uq_iper_ot UNIQUE (id_orden_trabajo),
    CONSTRAINT chk_iper_estado CHECK (estado_aprobacion_cliente IN ('PENDIENTE', 'APROBADO', 'RECHAZADO'))
);


CREATE TABLE ATS (
    id_ats NUMBER GENERATED ALWAYS AS IDENTITY,
    id_orden_trabajo NUMBER NOT NULL,
    fecha_elaboracion DATE DEFAULT SYSDATE NOT NULL,
    condiciones_area VARCHAR2(700),
    estado_ats VARCHAR2(30) DEFAULT 'ELABORADO' NOT NULL,
    fecha_aprobacion DATE,
    supervisor_cliente_firma VARCHAR2(150),
    ssoma_cliente_aprueba VARCHAR2(150),
    CONSTRAINT pk_ats PRIMARY KEY (id_ats),
    CONSTRAINT fk_ats_ot FOREIGN KEY (id_orden_trabajo) REFERENCES ORDEN_TRABAJO(id_orden_trabajo),
    CONSTRAINT uq_ats_ot UNIQUE (id_orden_trabajo),
    CONSTRAINT chk_ats_estado CHECK (estado_ats IN ('ELABORADO', 'APROBADO', 'RECHAZADO'))
);

CREATE TABLE DETALLE_ATS (
    id_detalle_ats NUMBER GENERATED ALWAYS AS IDENTITY,
    id_ats NUMBER NOT NULL,
    etapa_trabajo VARCHAR2(150) NOT NULL,
    peligro VARCHAR2(250) NOT NULL,
    riesgo VARCHAR2(250) NOT NULL,
    nivel_riesgo VARCHAR2(20) NOT NULL,
    medida_control VARCHAR2(500) NOT NULL,
    CONSTRAINT pk_detalle_ats PRIMARY KEY (id_detalle_ats),
    CONSTRAINT fk_detalle_ats FOREIGN KEY (id_ats) REFERENCES ATS(id_ats),
    CONSTRAINT chk_nivel_riesgo CHECK (nivel_riesgo IN ('ALTO', 'MEDIO', 'BAJO'))
);

CREATE TABLE EPP (
    id_epp NUMBER GENERATED ALWAYS AS IDENTITY,
    nombre_epp VARCHAR2(120) NOT NULL,
    descripcion VARCHAR2(250),
    CONSTRAINT pk_epp PRIMARY KEY (id_epp),
    CONSTRAINT uq_epp_nombre UNIQUE (nombre_epp)
);

CREATE TABLE HERRAMIENTA_EQUIPO (
    id_herramienta NUMBER GENERATED ALWAYS AS IDENTITY,
    nombre_herramienta VARCHAR2(120) NOT NULL,
    descripcion VARCHAR2(250),
    CONSTRAINT pk_herramienta PRIMARY KEY (id_herramienta),
    CONSTRAINT uq_herramienta_nombre UNIQUE (nombre_herramienta)
);

CREATE TABLE ATS_EPP (
    id_ats_epp NUMBER GENERATED ALWAYS AS IDENTITY,
    id_ats NUMBER NOT NULL,
    id_epp NUMBER NOT NULL,
    CONSTRAINT pk_ats_epp PRIMARY KEY (id_ats_epp),
    CONSTRAINT fk_ats_epp_ats FOREIGN KEY (id_ats) REFERENCES ATS(id_ats),
    CONSTRAINT fk_ats_epp_epp FOREIGN KEY (id_epp) REFERENCES EPP(id_epp),
    CONSTRAINT uq_ats_epp UNIQUE (id_ats, id_epp)
);

CREATE TABLE ATS_HERRAMIENTA (
    id_ats_herramienta NUMBER GENERATED ALWAYS AS IDENTITY,
    id_ats NUMBER NOT NULL,
    id_herramienta NUMBER NOT NULL,
    CONSTRAINT pk_ats_herramienta PRIMARY KEY (id_ats_herramienta),
    CONSTRAINT fk_ats_herr_ats FOREIGN KEY (id_ats) REFERENCES ATS(id_ats),
    CONSTRAINT fk_ats_herr_herr FOREIGN KEY (id_herramienta) REFERENCES HERRAMIENTA_EQUIPO(id_herramienta),
    CONSTRAINT uq_ats_herramienta UNIQUE (id_ats, id_herramienta)
);


CREATE TABLE ATENCION_SERVICIO (
    id_atencion NUMBER GENERATED ALWAYS AS IDENTITY,
    id_orden_trabajo NUMBER NOT NULL,
    fecha_registro DATE DEFAULT SYSDATE NOT NULL,
    descripcion_trabajo_realizado VARCHAR2(700),
    observaciones VARCHAR2(700),
    mediciones VARCHAR2(500),
    fecha_hora_registro TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
    CONSTRAINT pk_atencion PRIMARY KEY (id_atencion),
    CONSTRAINT fk_atencion_ot FOREIGN KEY (id_orden_trabajo) REFERENCES ORDEN_TRABAJO(id_orden_trabajo),
    CONSTRAINT uq_atencion_ot UNIQUE (id_orden_trabajo)
);

CREATE TABLE INFORME_TECNICO (
    id_informe NUMBER GENERATED ALWAYS AS IDENTITY,
    id_atencion NUMBER NOT NULL,
    fecha_elaboracion DATE DEFAULT SYSDATE NOT NULL,
    descripcion_informe VARCHAR2(1000),
    conclusiones VARCHAR2(700),
    fecha_envio_cliente DATE,
    CONSTRAINT pk_informe PRIMARY KEY (id_informe),
    CONSTRAINT fk_informe_atencion FOREIGN KEY (id_atencion) REFERENCES ATENCION_SERVICIO(id_atencion),
    CONSTRAINT uq_informe_atencion UNIQUE (id_atencion)
);

CREATE TABLE EVIDENCIA_FOTOGRAFICA (
    id_foto NUMBER GENERATED ALWAYS AS IDENTITY,
    id_informe NUMBER NOT NULL,
    tipo_evidencia VARCHAR2(20) NOT NULL,
    ruta_archivo VARCHAR2(300) NOT NULL,
    fecha_registro DATE DEFAULT SYSDATE NOT NULL,
    CONSTRAINT pk_evidencia PRIMARY KEY (id_foto),
    CONSTRAINT fk_evidencia_informe FOREIGN KEY (id_informe) REFERENCES INFORME_TECNICO(id_informe),
    CONSTRAINT chk_tipo_evidencia CHECK (tipo_evidencia IN ('ANTES', 'DURANTE', 'DESPUES'))
);

CREATE TABLE ACTA_CONFORMIDAD (
    id_acta NUMBER GENERATED ALWAYS AS IDENTITY,
    id_atencion NUMBER NOT NULL,
    numero_acta VARCHAR2(50) NOT NULL,
    fecha_conformidad DATE NOT NULL,
    observaciones VARCHAR2(500),
    CONSTRAINT pk_acta PRIMARY KEY (id_acta),
    CONSTRAINT fk_acta_atencion FOREIGN KEY (id_atencion) REFERENCES ATENCION_SERVICIO(id_atencion),
    CONSTRAINT uq_acta_numero UNIQUE (numero_acta),
    CONSTRAINT uq_acta_atencion UNIQUE (id_atencion)
);

CREATE TABLE UNIDAD_MEDIDA (
    id_unidad_medida NUMBER GENERATED ALWAYS AS IDENTITY,
    nombre_unidad VARCHAR2(80) NOT NULL,
    abreviatura VARCHAR2(20) NOT NULL,
    CONSTRAINT pk_unidad_medida PRIMARY KEY (id_unidad_medida),
    CONSTRAINT uq_unidad_nombre UNIQUE (nombre_unidad)
);

CREATE TABLE MATERIAL (
    id_material NUMBER GENERATED ALWAYS AS IDENTITY,
    id_unidad_medida NUMBER NOT NULL,
    nombre_material VARCHAR2(150) NOT NULL,
    stock_actual NUMBER(12,2) DEFAULT 0 NOT NULL,
    stock_minimo NUMBER(12,2) DEFAULT 0 NOT NULL,
    estado_material VARCHAR2(20) DEFAULT 'ACTIVO' NOT NULL,
    CONSTRAINT pk_material PRIMARY KEY (id_material),
    CONSTRAINT fk_material_unidad FOREIGN KEY (id_unidad_medida) REFERENCES UNIDAD_MEDIDA(id_unidad_medida),
    CONSTRAINT uq_material_nombre UNIQUE (nombre_material),
    CONSTRAINT chk_material_stock CHECK (stock_actual >= 0),
    CONSTRAINT chk_material_stock_min CHECK (stock_minimo >= 0),
    CONSTRAINT chk_material_estado CHECK (estado_material IN ('ACTIVO', 'INACTIVO'))
);

CREATE TABLE DETALLE_MATERIAL_SERVICIO (
    id_detalle_material NUMBER GENERATED ALWAYS AS IDENTITY,
    id_orden_trabajo NUMBER NOT NULL,
    id_material NUMBER NOT NULL,
    cantidad_asignada NUMBER(12,2) DEFAULT 0 NOT NULL,
    cantidad_utilizada NUMBER(12,2) DEFAULT 0 NOT NULL,
    CONSTRAINT pk_detalle_material PRIMARY KEY (id_detalle_material),
    CONSTRAINT fk_detalle_mat_ot FOREIGN KEY (id_orden_trabajo) REFERENCES ORDEN_TRABAJO(id_orden_trabajo),
    CONSTRAINT fk_detalle_mat_material FOREIGN KEY (id_material) REFERENCES MATERIAL(id_material),
    CONSTRAINT uq_detalle_material UNIQUE (id_orden_trabajo, id_material),
    CONSTRAINT chk_cant_asignada CHECK (cantidad_asignada >= 0),
    CONSTRAINT chk_cant_utilizada CHECK (cantidad_utilizada >= 0)
);

CREATE TABLE MOVIMIENTO_ALMACEN (
    id_movimiento NUMBER GENERATED ALWAYS AS IDENTITY,
    id_orden_trabajo NUMBER,
    id_material NUMBER NOT NULL,
    tipo_movimiento VARCHAR2(20) NOT NULL,
    cantidad NUMBER(12,2) NOT NULL,
    fecha_movimiento DATE DEFAULT SYSDATE NOT NULL,
    CONSTRAINT pk_movimiento PRIMARY KEY (id_movimiento),
    CONSTRAINT fk_movimiento_ot FOREIGN KEY (id_orden_trabajo) REFERENCES ORDEN_TRABAJO(id_orden_trabajo),
    CONSTRAINT fk_movimiento_material FOREIGN KEY (id_material) REFERENCES MATERIAL(id_material),
    CONSTRAINT chk_movimiento_tipo CHECK (tipo_movimiento IN ('ENTRADA', 'SALIDA', 'DEVOLUCION')),
    CONSTRAINT chk_movimiento_cantidad CHECK (cantidad > 0)
    );