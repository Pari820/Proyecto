package com.example.cliente_pedido.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

@Entity
@Table(name = "ESPECIALIDAD")
@Data @NoArgsConstructor @AllArgsConstructor
public class Especialidad {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_especialidad")
    private Long idEspecialidad;

    @NotBlank
    @Column(name = "nombre_especialidad", nullable = false, length = 100, unique = true)
    private String nombreEspecialidad;

    @Column(name = "descripcion", length = 250)
    private String descripcion;
}
