package com.example.cliente_pedido.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

@Entity
@Table(name = "USUARIO")
@Data @NoArgsConstructor @AllArgsConstructor
public class Usuario {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_usuario")
    private Long idUsuario;

    @ManyToOne
    @JoinColumn(name = "id_persona", nullable = false, unique = true)
    private Persona persona;

    @NotBlank
    @Column(name = "nombre_usuario", nullable = false, length = 80, unique = true)
    private String nombreUsuario;

    @NotBlank
    @Column(name = "contrasena", nullable = false, length = 255)
    private String contrasena;

    @Column(name = "estado_usuario", nullable = false, length = 20)
    private String estadoUsuario = "ACTIVO";
}
