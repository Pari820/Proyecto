package com.example.cliente_pedido.serviceimpl;

import com.example.cliente_pedido.model.Persona;
import com.example.cliente_pedido.repository.PersonaRepository;
import com.example.cliente_pedido.service.PersonaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.Optional;

@Service
public class PersonaServiceImpl implements PersonaService {
    @Autowired private PersonaRepository repository;

    @Override public Persona create(Persona p) { return repository.save(p); }
    @Override public Persona update(Persona p) { return repository.save(p); }
    @Override public Optional<Persona> read(Long id) { return repository.findById(id); }
    @Override public void delete(Long id) { repository.deleteById(id); }
    @Override public Iterable<Persona> readAll() { return repository.findAll(); }
}
