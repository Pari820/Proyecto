package com.example.cliente_pedido.serviceimpl;

import com.example.cliente_pedido.model.ActaConformidad;
import com.example.cliente_pedido.repository.ActaConformidadRepository;
import com.example.cliente_pedido.service.ActaConformidadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ActaConformidadServiceImpl implements ActaConformidadService {

    @Autowired
    private ActaConformidadRepository repository;

    @Override
    public ActaConformidad create(ActaConformidad obj) {
        return repository.save(obj);
    }

    @Override
    public ActaConformidad update(ActaConformidad obj) {
        return repository.save(obj);
    }

    @Override
    public Optional<ActaConformidad> read(Long id) {
        return repository.findById(id);
    }

    @Override
    public void delete(Long id) {
        repository.deleteById(id);
    }

    @Override
    public Iterable<ActaConformidad> readAll() {
        return repository.findAll();
    }
}
