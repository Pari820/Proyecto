package com.example.cliente_pedido.repository;

import com.example.cliente_pedido.model.AtencionServicio;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AtencionServicioRepository extends JpaRepository<AtencionServicio, Long> {
}
