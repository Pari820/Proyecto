package com.example.cliente_pedido.serviceimpl;

import com.example.cliente_pedido.model.SolicitudServicio;
import com.example.cliente_pedido.repository.SolicitudServicioRepository;
import com.example.cliente_pedido.service.SolicitudServicioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class SolicitudServicioServiceImpl implements SolicitudServicioService {

    @Autowired
    private SolicitudServicioRepository repository;

    @Override
    public SolicitudServicio create(SolicitudServicio obj) {
        return repository.save(obj);
    }

    @Override
    public SolicitudServicio update(SolicitudServicio obj) {
        return repository.save(obj);
    }

    @Override
    public Optional<SolicitudServicio> read(Long id) {
        return repository.findById(id);
    }

    @Override
    public void delete(Long id) {
        repository.deleteById(id);
    }

    @Override
    public Iterable<SolicitudServicio> readAll() {
        return repository.findAll();
    }
}
