package com.example.cliente_pedido.controller;

import com.example.cliente_pedido.model.Empleado;
import com.example.cliente_pedido.model.Persona;
import com.example.cliente_pedido.service.*;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.time.LocalDate;

@Controller
@RequestMapping("/empleado")
public class EmpleadoController {

    @Autowired private EmpleadoService empleadoService;
    @Autowired private PersonaService personaService;
    @Autowired private CargoService cargoService;
    @Autowired private EspecialidadService especialidadService;

    private boolean sinSesion(HttpSession s) { return s.getAttribute("usuarioId") == null; }

    @GetMapping
    public String listar(Model model, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        model.addAttribute("lista", empleadoService.readAll());
        return "empleado/lista";
    }

    @GetMapping("/nuevo")
    public String nuevo(Model model, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        model.addAttribute("empleado", new Empleado());
        model.addAttribute("persona", new Persona());
        model.addAttribute("cargos", cargoService.readAll());
        model.addAttribute("especialidades", especialidadService.readAll());
        return "empleado/form";
    }

    @PostMapping("/guardar")
    public String guardar(
            @ModelAttribute("persona") Persona persona,
            @ModelAttribute("empleado") Empleado empleado,
            RedirectAttributes ra, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        persona = personaService.create(persona);
        empleado.setPersona(persona);
        empleado.setEstadoEmpleado("ACTIVO");
        if (empleado.getFechaIngreso() == null) empleado.setFechaIngreso(LocalDate.now());
        empleadoService.create(empleado);
        ra.addFlashAttribute("mensajeExito", "Empleado registrado correctamente.");
        return "redirect:/empleado";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id, RedirectAttributes ra, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        try {
            empleadoService.delete(id);
            ra.addFlashAttribute("mensajeExito", "Empleado eliminado.");
        } catch (Exception e) {
            ra.addFlashAttribute("mensajeError", "No se puede eliminar. Tiene registros asociados.");
        }
        return "redirect:/empleado";
    }
}
