package com.example.cliente_pedido.controller;

import com.example.cliente_pedido.model.ActaConformidad;
import com.example.cliente_pedido.service.ActaConformidadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/acta-conformidad")
public class ActaConformidadRestController {

    @Autowired
    private ActaConformidadService service;

    @GetMapping
    public Iterable<ActaConformidad> listar() {
        return service.readAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<ActaConformidad> buscarPorId(@PathVariable Long id) {
        return service.read(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ActaConformidad crear(@RequestBody ActaConformidad obj) {
        return service.create(obj);
    }

    @PutMapping("/{id}")
    public ResponseEntity<ActaConformidad> actualizar(@PathVariable Long id, @RequestBody ActaConformidad obj) {
        return service.read(id)
                .map(existente -> ResponseEntity.ok(service.update(obj)))
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        if (service.read(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
