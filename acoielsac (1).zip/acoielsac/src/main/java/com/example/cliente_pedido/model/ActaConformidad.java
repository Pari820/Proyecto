package com.example.cliente_pedido.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;
import java.time.LocalDate;

@Entity
@Table(name = "ACTA_CONFORMIDAD")
@Data @NoArgsConstructor @AllArgsConstructor
public class ActaConformidad {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_acta")
    private Long idActa;

    @OneToOne
    @JoinColumn(name = "id_atencion", nullable = false, unique = true)
    private AtencionServicio atencionServicio;

    @NotBlank
    @Column(name = "numero_acta", nullable = false, length = 50, unique = true)
    private String numeroActa;

    @Column(name = "fecha_conformidad", nullable = false)
    private LocalDate fechaConformidad;

    @Column(name = "observaciones", length = 500)
    private String observaciones;
}
