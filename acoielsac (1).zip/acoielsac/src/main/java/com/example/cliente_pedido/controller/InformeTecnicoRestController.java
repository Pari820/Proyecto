package com.example.cliente_pedido.controller;

import com.example.cliente_pedido.model.InformeTecnico;
import com.example.cliente_pedido.service.InformeTecnicoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/informe-tecnico")
public class InformeTecnicoRestController {

    @Autowired
    private InformeTecnicoService service;

    @GetMapping
    public Iterable<InformeTecnico> listar() {
        return service.readAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<InformeTecnico> buscarPorId(@PathVariable Long id) {
        return service.read(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public InformeTecnico crear(@RequestBody InformeTecnico obj) {
        return service.create(obj);
    }

    @PutMapping("/{id}")
    public ResponseEntity<InformeTecnico> actualizar(@PathVariable Long id, @RequestBody InformeTecnico obj) {
        return service.read(id)
                .map(existente -> ResponseEntity.ok(service.update(obj)))
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        if (service.read(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
