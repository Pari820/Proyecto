package com.example.cliente_pedido.controller;

import com.example.cliente_pedido.model.DetalleMaterialServicio;
import com.example.cliente_pedido.service.DetalleMaterialServicioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/detalle-material-servicio")
public class DetalleMaterialServicioRestController {

    @Autowired
    private DetalleMaterialServicioService service;

    @GetMapping
    public Iterable<DetalleMaterialServicio> listar() {
        return service.readAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<DetalleMaterialServicio> buscarPorId(@PathVariable Long id) {
        return service.read(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public DetalleMaterialServicio crear(@RequestBody DetalleMaterialServicio obj) {
        return service.create(obj);
    }

    @PutMapping("/{id}")
    public ResponseEntity<DetalleMaterialServicio> actualizar(@PathVariable Long id, @RequestBody DetalleMaterialServicio obj) {
        return service.read(id)
                .map(existente -> ResponseEntity.ok(service.update(obj)))
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        if (service.read(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
