package com.example.cliente_pedido.service;

import com.example.cliente_pedido.generic.CrudService;
import com.example.cliente_pedido.model.ActaConformidad;

public interface ActaConformidadService extends CrudService<ActaConformidad, Long> {
}
