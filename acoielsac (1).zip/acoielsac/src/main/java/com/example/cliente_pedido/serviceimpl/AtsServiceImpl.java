package com.example.cliente_pedido.serviceimpl;

import com.example.cliente_pedido.model.Ats;
import com.example.cliente_pedido.repository.AtsRepository;
import com.example.cliente_pedido.service.AtsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AtsServiceImpl implements AtsService {

    @Autowired
    private AtsRepository repository;

    @Override
    public Ats create(Ats obj) {
        return repository.save(obj);
    }

    @Override
    public Ats update(Ats obj) {
        return repository.save(obj);
    }

    @Override
    public Optional<Ats> read(Long id) {
        return repository.findById(id);
    }

    @Override
    public void delete(Long id) {
        repository.deleteById(id);
    }

    @Override
    public Iterable<Ats> readAll() {
        return repository.findAll();
    }
}
