package com.example.cliente_pedido.service;

import com.example.cliente_pedido.generic.CrudService;
import com.example.cliente_pedido.model.DetalleAts;

public interface DetalleAtsService extends CrudService<DetalleAts, Long> {
}
