package com.example.cliente_pedido.controller;

import com.example.cliente_pedido.model.ProcedimientoTrabajo;
import com.example.cliente_pedido.service.ProcedimientoTrabajoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/procedimiento-trabajo")
public class ProcedimientoTrabajoRestController {

    @Autowired
    private ProcedimientoTrabajoService service;

    @GetMapping
    public Iterable<ProcedimientoTrabajo> listar() {
        return service.readAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<ProcedimientoTrabajo> buscarPorId(@PathVariable Long id) {
        return service.read(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ProcedimientoTrabajo crear(@RequestBody ProcedimientoTrabajo obj) {
        return service.create(obj);
    }

    @PutMapping("/{id}")
    public ResponseEntity<ProcedimientoTrabajo> actualizar(@PathVariable Long id, @RequestBody ProcedimientoTrabajo obj) {
        return service.read(id)
                .map(existente -> ResponseEntity.ok(service.update(obj)))
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        if (service.read(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
