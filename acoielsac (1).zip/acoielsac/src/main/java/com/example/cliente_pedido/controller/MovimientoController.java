package com.example.cliente_pedido.controller;

import com.example.cliente_pedido.model.Material;
import com.example.cliente_pedido.model.MovimientoAlmacen;
import com.example.cliente_pedido.service.MaterialService;
import com.example.cliente_pedido.service.MovimientoAlmacenService;
import com.example.cliente_pedido.service.OrdenTrabajoService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.math.BigDecimal;
import java.time.LocalDate;

@Controller
@RequestMapping("/movimiento")
public class MovimientoController {

    @Autowired private MovimientoAlmacenService service;
    @Autowired private MaterialService materialService;
    @Autowired private OrdenTrabajoService ordenTrabajoService;

    private boolean sinSesion(HttpSession s) { return s.getAttribute("usuarioId") == null; }

    @GetMapping
    public String listar(Model model, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        model.addAttribute("lista", service.readAll());
        return "movimiento/lista";
    }

    @GetMapping("/nuevo")
    public String nuevo(Model model, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        MovimientoAlmacen obj = new MovimientoAlmacen();
        obj.setFechaMovimiento(LocalDate.now());
        model.addAttribute("obj", obj);
        model.addAttribute("materiales", materialService.readAll());
        model.addAttribute("ordenesTrabajo", ordenTrabajoService.readAll());
        return "movimiento/form";
    }

    @PostMapping("/guardar")
    public String guardar(@ModelAttribute("obj") MovimientoAlmacen obj,
                          Model model, RedirectAttributes ra, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";

        // Validar material
        if (obj.getMaterial() == null || obj.getMaterial().getIdMaterial() == null) {
            model.addAttribute("mensajeError", "Debe seleccionar un material.");
            model.addAttribute("materiales", materialService.readAll());
            model.addAttribute("ordenesTrabajo", ordenTrabajoService.readAll());
            return "movimiento/form";
        }

        Material mat = materialService.read(obj.getMaterial().getIdMaterial()).orElse(null);
        if (mat == null) {
            model.addAttribute("mensajeError", "Material no encontrado.");
            model.addAttribute("materiales", materialService.readAll());
            model.addAttribute("ordenesTrabajo", ordenTrabajoService.readAll());
            return "movimiento/form";
        }

        BigDecimal cantidad = obj.getCantidad();
        if (cantidad == null || cantidad.compareTo(BigDecimal.ZERO) <= 0) {
            model.addAttribute("mensajeError", "La cantidad debe ser mayor a cero.");
            model.addAttribute("materiales", materialService.readAll());
            model.addAttribute("ordenesTrabajo", ordenTrabajoService.readAll());
            return "movimiento/form";
        }

        // Actualizar stock
        if ("SALIDA".equals(obj.getTipoMovimiento()) || "DEVOLUCION".equals(obj.getTipoMovimiento()) && obj.getTipoMovimiento().equals("DEVOLUCION")) {
            if ("SALIDA".equals(obj.getTipoMovimiento())) {
                BigDecimal nuevoStock = mat.getStockActual().subtract(cantidad);
                if (nuevoStock.compareTo(BigDecimal.ZERO) < 0) {
                    model.addAttribute("mensajeError",
                        "Stock insuficiente. Stock actual: " + mat.getStockActual());
                    model.addAttribute("materiales", materialService.readAll());
                    model.addAttribute("ordenesTrabajo", ordenTrabajoService.readAll());
                    return "movimiento/form";
                }
                mat.setStockActual(nuevoStock);
            }
        } else if ("ENTRADA".equals(obj.getTipoMovimiento())) {
            mat.setStockActual(mat.getStockActual().add(cantidad));
        } else if ("DEVOLUCION".equals(obj.getTipoMovimiento())) {
            mat.setStockActual(mat.getStockActual().add(cantidad));
        }

        materialService.update(mat);
        obj.setMaterial(mat);
        if (obj.getFechaMovimiento() == null) obj.setFechaMovimiento(LocalDate.now());
        service.create(obj);
        ra.addFlashAttribute("mensajeExito", "Movimiento registrado. Stock actualizado.");
        return "redirect:/movimiento";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id, RedirectAttributes ra, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        try { service.delete(id); ra.addFlashAttribute("mensajeExito", "Movimiento eliminado."); }
        catch (Exception e) { ra.addFlashAttribute("mensajeError", "No se puede eliminar."); }
        return "redirect:/movimiento";
    }
}
