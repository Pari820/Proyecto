package com.example.cliente_pedido.serviceimpl;

import com.example.cliente_pedido.model.OrdenTrabajo;
import com.example.cliente_pedido.repository.OrdenTrabajoRepository;
import com.example.cliente_pedido.service.OrdenTrabajoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class OrdenTrabajoServiceImpl implements OrdenTrabajoService {

    @Autowired
    private OrdenTrabajoRepository repository;

    @Override
    public OrdenTrabajo create(OrdenTrabajo obj) {
        return repository.save(obj);
    }

    @Override
    public OrdenTrabajo update(OrdenTrabajo obj) {
        return repository.save(obj);
    }

    @Override
    public Optional<OrdenTrabajo> read(Long id) {
        return repository.findById(id);
    }

    @Override
    public void delete(Long id) {
        repository.deleteById(id);
    }

    @Override
    public Iterable<OrdenTrabajo> readAll() {
        return repository.findAll();
    }
}
