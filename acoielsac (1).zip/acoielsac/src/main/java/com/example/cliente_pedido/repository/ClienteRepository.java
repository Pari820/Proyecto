package com.example.cliente_pedido.repository;

import com.example.cliente_pedido.model.Cliente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.Optional;

@Repository
public interface ClienteRepository extends JpaRepository<Cliente, Long> {
    Optional<Cliente> findByRuc(String ruc);
    boolean existsByRuc(String ruc);
}
