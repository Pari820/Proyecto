package com.example.cliente_pedido.repository;

import com.example.cliente_pedido.model.ContactoCliente;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ContactoClienteRepository extends JpaRepository<ContactoCliente, Long> {
}
