package com.example.cliente_pedido.controller;

import com.example.cliente_pedido.model.Ats;
import com.example.cliente_pedido.service.AtsService;
import com.example.cliente_pedido.service.OrdenTrabajoService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.time.LocalDate;

@Controller
@RequestMapping("/ats")
public class AtsController {

    @Autowired private AtsService service;
    @Autowired private OrdenTrabajoService ordenTrabajoService;

    private boolean sinSesion(HttpSession s) { return s.getAttribute("usuarioId") == null; }

    @GetMapping
    public String listar(Model model, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        model.addAttribute("lista", service.readAll());
        return "ats/lista";
    }

    @GetMapping("/nuevo")
    public String nuevo(Model model, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        Ats obj = new Ats();
        obj.setFechaElaboracion(LocalDate.now());
        obj.setEstadoAts("ELABORADO");
        model.addAttribute("obj", obj);
        model.addAttribute("ordenesTrabajo", ordenTrabajoService.readAll());
        return "ats/form";
    }

    @PostMapping("/guardar")
    public String guardar(@ModelAttribute("obj") Ats obj,
                          RedirectAttributes ra, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        if (obj.getEstadoAts() == null) obj.setEstadoAts("ELABORADO");
        service.create(obj);
        ra.addFlashAttribute("mensajeExito", "ATS registrado correctamente.");
        return "redirect:/ats";
    }

    @GetMapping("/aprobacion")
    public String listarAprobacion(Model model, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        model.addAttribute("lista", service.readAll());
        return "ats/aprobacion";
    }

    @GetMapping("/aprobar/{id}")
    public String aprobar(@PathVariable Long id, RedirectAttributes ra, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        Ats ats = service.read(id).orElse(null);
        if (ats != null) {
            ats.setEstadoAts("APROBADO");
            ats.setFechaAprobacion(LocalDate.now());
            service.update(ats);
            ra.addFlashAttribute("mensajeExito", "ATS aprobado correctamente.");
        }
        return "redirect:/ats/aprobacion";
    }

    @GetMapping("/rechazar/{id}")
    public String rechazar(@PathVariable Long id, RedirectAttributes ra, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        Ats ats = service.read(id).orElse(null);
        if (ats != null) {
            ats.setEstadoAts("RECHAZADO");
            service.update(ats);
            ra.addFlashAttribute("mensajeExito", "ATS rechazado.");
        }
        return "redirect:/ats/aprobacion";
    }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Long id, Model model, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        Ats obj = service.read(id).orElse(null);
        if (obj == null) return "redirect:/ats";
        model.addAttribute("obj", obj);
        model.addAttribute("ordenesTrabajo", ordenTrabajoService.readAll());
        return "ats/form";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id, RedirectAttributes ra, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        try { service.delete(id); ra.addFlashAttribute("mensajeExito", "ATS eliminado."); }
        catch (Exception e) { ra.addFlashAttribute("mensajeError", "No se puede eliminar."); }
        return "redirect:/ats";
    }
}
