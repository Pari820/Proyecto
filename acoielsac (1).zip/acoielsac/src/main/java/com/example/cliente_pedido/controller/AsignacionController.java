package com.example.cliente_pedido.controller;
import com.example.cliente_pedido.model.AsignacionPersonal;
import com.example.cliente_pedido.service.AsignacionPersonalService;
import com.example.cliente_pedido.service.EmpleadoService;
import com.example.cliente_pedido.service.OrdenTrabajoService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.time.LocalDate;

@Controller
@RequestMapping("/asignacion")
public class AsignacionController {
    @Autowired private AsignacionPersonalService service;
    @Autowired private OrdenTrabajoService otService;
    @Autowired private EmpleadoService empleadoService;
    private boolean sinSesion(HttpSession s) { return s.getAttribute("usuarioId") == null; }

    @GetMapping public String listar(Model m, HttpSession s) {
        if(sinSesion(s)) return "redirect:/login";
        m.addAttribute("lista", service.readAll()); return "asignacion/lista"; }

    @GetMapping("/nuevo") public String nuevo(Model m, HttpSession s) {
        if(sinSesion(s)) return "redirect:/login";
        AsignacionPersonal obj = new AsignacionPersonal();
        obj.setFechaAsignacion(LocalDate.now());
        m.addAttribute("obj", obj);
        m.addAttribute("ordenesTrabajo", otService.readAll());
        m.addAttribute("empleados", empleadoService.readAll());
        return "asignacion/form"; }

    @PostMapping("/guardar") public String guardar(@ModelAttribute("obj") AsignacionPersonal obj,
            RedirectAttributes ra, HttpSession s) {
        if(sinSesion(s)) return "redirect:/login";
        if(obj.getFechaAsignacion()==null) obj.setFechaAsignacion(LocalDate.now());
        service.create(obj);
        ra.addFlashAttribute("mensajeExito","Personal asignado correctamente.");
        return "redirect:/asignacion"; }

    @GetMapping("/eliminar/{id}") public String eliminar(@PathVariable Long id, RedirectAttributes ra, HttpSession s) {
        if(sinSesion(s)) return "redirect:/login";
        try { service.delete(id); ra.addFlashAttribute("mensajeExito","Asignacion eliminada."); }
        catch(Exception e) { ra.addFlashAttribute("mensajeError","No se puede eliminar."); }
        return "redirect:/asignacion"; }
}
