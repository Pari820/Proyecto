package com.example.cliente_pedido.service;

import com.example.cliente_pedido.generic.CrudService;
import com.example.cliente_pedido.model.ContactoCliente;

public interface ContactoClienteService extends CrudService<ContactoCliente, Long> {
}
