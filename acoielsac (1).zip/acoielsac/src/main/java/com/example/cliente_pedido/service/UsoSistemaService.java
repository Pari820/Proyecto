package com.example.cliente_pedido.service;

import com.example.cliente_pedido.generic.CrudService;
import com.example.cliente_pedido.model.UsoSistema;

public interface UsoSistemaService extends CrudService<UsoSistema, Long> {
}
