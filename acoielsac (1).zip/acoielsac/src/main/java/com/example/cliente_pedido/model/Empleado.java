package com.example.cliente_pedido.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

@Entity
@Table(name = "EMPLEADO")
@Data @NoArgsConstructor @AllArgsConstructor
public class Empleado {

    @Id
    @Column(name = "id_persona")
    private Long idPersona;

    @OneToOne
    @MapsId
    @JoinColumn(name = "id_persona")
    private Persona persona;

    @Column(name = "codigo_empleado", length = 30, unique = true)
    private String codigoEmpleado;

    @Column(name = "fecha_ingreso")
    private LocalDate fechaIngreso;

    @Column(name = "estado_empleado", nullable = false, length = 20)
    private String estadoEmpleado = "ACTIVO";

    @ManyToOne
    @JoinColumn(name = "id_cargo", nullable = false)
    private Cargo cargo;

    @ManyToOne
    @JoinColumn(name = "id_especialidad")
    private Especialidad especialidad;
}
