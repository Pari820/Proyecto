package com.example.cliente_pedido.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

@Entity
@Table(name = "TIPO_SERVICIO")
@Data @NoArgsConstructor @AllArgsConstructor
public class TipoServicio {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_tipo_servicio")
    private Long idTipoServicio;

    @NotBlank
    @Column(name = "nombre_tipo_servicio", nullable = false, length = 120, unique = true)
    private String nombreTipoServicio;

    @Column(name = "descripcion", length = 300)
    private String descripcion;

    @Column(name = "estado", nullable = false, length = 20)
    private String estado = "ACTIVO";
}
