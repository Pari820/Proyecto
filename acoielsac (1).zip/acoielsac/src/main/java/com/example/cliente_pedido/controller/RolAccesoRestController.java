package com.example.cliente_pedido.controller;

import com.example.cliente_pedido.model.RolAcceso;
import com.example.cliente_pedido.service.RolAccesoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/rol-acceso")
public class RolAccesoRestController {

    @Autowired
    private RolAccesoService service;

    @GetMapping
    public Iterable<RolAcceso> listar() {
        return service.readAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<RolAcceso> buscarPorId(@PathVariable Long id) {
        return service.read(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public RolAcceso crear(@RequestBody RolAcceso obj) {
        return service.create(obj);
    }

    @PutMapping("/{id}")
    public ResponseEntity<RolAcceso> actualizar(@PathVariable Long id, @RequestBody RolAcceso obj) {
        return service.read(id)
                .map(existente -> ResponseEntity.ok(service.update(obj)))
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        if (service.read(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
