package com.example.cliente_pedido.model;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;

@Entity
@Table(name = "DETALLE_MATERIAL_SERVICIO", uniqueConstraints = @UniqueConstraint(columnNames = {"id_orden_trabajo", "id_material"}))
@Data @NoArgsConstructor @AllArgsConstructor
public class DetalleMaterialServicio {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_detalle_material")
    private Long idDetalleMaterial;

    @ManyToOne
    @JoinColumn(name = "id_orden_trabajo", nullable = false)
    private OrdenTrabajo ordenTrabajo;

    @ManyToOne
    @JoinColumn(name = "id_material", nullable = false)
    private Material material;

    @Column(name = "cantidad_asignada", nullable = false, precision = 12, scale = 2)
    private BigDecimal cantidadAsignada = BigDecimal.ZERO;

    @Column(name = "cantidad_utilizada", nullable = false, precision = 12, scale = 2)
    private BigDecimal cantidadUtilizada = BigDecimal.ZERO;
}
