package com.example.cliente_pedido.controller;
import com.example.cliente_pedido.model.Cargo;
import com.example.cliente_pedido.service.CargoService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/cargo")
public class CargoController {
    @Autowired private CargoService service;
    private boolean sinSesion(HttpSession s) { return s.getAttribute("usuarioId") == null; }
    @GetMapping public String listar(Model m, HttpSession s) {
        if(sinSesion(s)) return "redirect:/login";
        m.addAttribute("lista", service.readAll()); return "cargo/lista"; }
    @GetMapping("/nuevo") public String nuevo(Model m, HttpSession s) {
        if(sinSesion(s)) return "redirect:/login";
        m.addAttribute("obj", new Cargo()); return "cargo/form"; }
    @PostMapping("/guardar") public String guardar(@Valid @ModelAttribute("obj") Cargo obj, BindingResult r, RedirectAttributes ra, HttpSession s) {
        if(sinSesion(s)) return "redirect:/login";
        if(r.hasErrors()) return "cargo/form";
        service.create(obj); ra.addFlashAttribute("mensajeExito","Cargo guardado."); return "redirect:/cargo"; }
    @GetMapping("/editar/{id}") public String editar(@PathVariable Long id, Model m, HttpSession s) {
        if(sinSesion(s)) return "redirect:/login";
        Cargo obj = service.read(id).orElse(null); if(obj==null) return "redirect:/cargo";
        m.addAttribute("obj",obj); return "cargo/form"; }
    @GetMapping("/eliminar/{id}") public String eliminar(@PathVariable Long id, RedirectAttributes ra, HttpSession s) {
        if(sinSesion(s)) return "redirect:/login";
        try { service.delete(id); ra.addFlashAttribute("mensajeExito","Cargo eliminado."); }
        catch(Exception e) { ra.addFlashAttribute("mensajeError","No se puede eliminar."); }
        return "redirect:/cargo"; }
}
