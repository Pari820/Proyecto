package com.example.cliente_pedido.serviceimpl;

import com.example.cliente_pedido.model.AsignacionPersonal;
import com.example.cliente_pedido.repository.AsignacionPersonalRepository;
import com.example.cliente_pedido.service.AsignacionPersonalService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AsignacionPersonalServiceImpl implements AsignacionPersonalService {

    @Autowired
    private AsignacionPersonalRepository repository;

    @Override
    public AsignacionPersonal create(AsignacionPersonal obj) {
        return repository.save(obj);
    }

    @Override
    public AsignacionPersonal update(AsignacionPersonal obj) {
        return repository.save(obj);
    }

    @Override
    public Optional<AsignacionPersonal> read(Long id) {
        return repository.findById(id);
    }

    @Override
    public void delete(Long id) {
        repository.deleteById(id);
    }

    @Override
    public Iterable<AsignacionPersonal> readAll() {
        return repository.findAll();
    }
}
