package com.example.cliente_pedido.service;

import com.example.cliente_pedido.generic.CrudService;
import com.example.cliente_pedido.model.Usuario;

public interface UsuarioService extends CrudService<Usuario, Long> {
}
