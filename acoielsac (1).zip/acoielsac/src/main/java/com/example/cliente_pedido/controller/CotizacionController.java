package com.example.cliente_pedido.controller;

import com.example.cliente_pedido.model.Cotizacion;
import com.example.cliente_pedido.service.CotizacionService;
import com.example.cliente_pedido.service.SolicitudServicioService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.time.LocalDate;

@Controller
@RequestMapping("/cotizacion")
public class CotizacionController {

    @Autowired private CotizacionService service;
    @Autowired private SolicitudServicioService solicitudService;

    private boolean sinSesion(HttpSession s) { return s.getAttribute("usuarioId") == null; }

    @GetMapping
    public String listar(Model model, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        model.addAttribute("lista", service.readAll());
        return "cotizacion/lista";
    }

    @GetMapping("/nuevo")
    public String nuevo(Model model, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        Cotizacion obj = new Cotizacion();
        obj.setFechaCotizacion(LocalDate.now());
        obj.setEstadoCotizacion("EMITIDA");
        model.addAttribute("obj", obj);
        model.addAttribute("solicitudes", solicitudService.readAll());
        return "cotizacion/form";
    }

    @PostMapping("/guardar")
    public String guardar(@ModelAttribute("obj") Cotizacion obj,
                          Model model, RedirectAttributes ra, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        if (obj.getMontoEstimado() == null) {
            model.addAttribute("mensajeError", "El monto es obligatorio.");
            model.addAttribute("solicitudes", solicitudService.readAll());
            return "cotizacion/form";
        }
        if (obj.getEstadoCotizacion() == null) obj.setEstadoCotizacion("EMITIDA");
        service.create(obj);
        ra.addFlashAttribute("mensajeExito", "Cotizacion guardada correctamente.");
        return "redirect:/cotizacion";
    }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Long id, Model model, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        Cotizacion obj = service.read(id).orElse(null);
        if (obj == null) return "redirect:/cotizacion";
        model.addAttribute("obj", obj);
        model.addAttribute("solicitudes", solicitudService.readAll());
        return "cotizacion/form";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id, RedirectAttributes ra, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        try {
            service.delete(id);
            ra.addFlashAttribute("mensajeExito", "Cotizacion eliminada.");
        } catch (Exception e) {
            ra.addFlashAttribute("mensajeError", "No se puede eliminar. Tiene registros asociados.");
        }
        return "redirect:/cotizacion";
    }
}
