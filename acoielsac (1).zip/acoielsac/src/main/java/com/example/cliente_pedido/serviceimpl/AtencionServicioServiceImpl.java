package com.example.cliente_pedido.serviceimpl;

import com.example.cliente_pedido.model.AtencionServicio;
import com.example.cliente_pedido.repository.AtencionServicioRepository;
import com.example.cliente_pedido.service.AtencionServicioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AtencionServicioServiceImpl implements AtencionServicioService {

    @Autowired
    private AtencionServicioRepository repository;

    @Override
    public AtencionServicio create(AtencionServicio obj) {
        return repository.save(obj);
    }

    @Override
    public AtencionServicio update(AtencionServicio obj) {
        return repository.save(obj);
    }

    @Override
    public Optional<AtencionServicio> read(Long id) {
        return repository.findById(id);
    }

    @Override
    public void delete(Long id) {
        repository.deleteById(id);
    }

    @Override
    public Iterable<AtencionServicio> readAll() {
        return repository.findAll();
    }
}
