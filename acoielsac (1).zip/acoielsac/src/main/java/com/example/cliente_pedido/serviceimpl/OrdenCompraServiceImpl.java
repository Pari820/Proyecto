package com.example.cliente_pedido.serviceimpl;

import com.example.cliente_pedido.model.OrdenCompra;
import com.example.cliente_pedido.repository.OrdenCompraRepository;
import com.example.cliente_pedido.service.OrdenCompraService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class OrdenCompraServiceImpl implements OrdenCompraService {

    @Autowired
    private OrdenCompraRepository repository;

    @Override
    public OrdenCompra create(OrdenCompra obj) {
        return repository.save(obj);
    }

    @Override
    public OrdenCompra update(OrdenCompra obj) {
        return repository.save(obj);
    }

    @Override
    public Optional<OrdenCompra> read(Long id) {
        return repository.findById(id);
    }

    @Override
    public void delete(Long id) {
        repository.deleteById(id);
    }

    @Override
    public Iterable<OrdenCompra> readAll() {
        return repository.findAll();
    }
}
