package com.example.cliente_pedido.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

@Entity
@Table(name = "DETALLE_ATS")
@Data @NoArgsConstructor @AllArgsConstructor
public class DetalleAts {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_detalle_ats")
    private Long idDetalleAts;

    @ManyToOne
    @JoinColumn(name = "id_ats", nullable = false)
    private Ats ats;

    @NotBlank
    @Column(name = "etapa_trabajo", nullable = false, length = 150)
    private String etapaTrabajo;

    @NotBlank
    @Column(name = "peligro", nullable = false, length = 250)
    private String peligro;

    @NotBlank
    @Column(name = "riesgo", nullable = false, length = 250)
    private String riesgo;

    @NotBlank
    @Column(name = "nivel_riesgo", nullable = false, length = 20)
    private String nivelRiesgo;

    @NotBlank
    @Column(name = "medida_control", nullable = false, length = 500)
    private String medidaControl;
}
