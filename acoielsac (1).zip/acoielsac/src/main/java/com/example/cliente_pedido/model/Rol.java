package com.example.cliente_pedido.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

@Entity
@Table(name = "ROL")
@Data @NoArgsConstructor @AllArgsConstructor
public class Rol {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_rol")
    private Long idRol;

    @NotBlank
    @Column(name = "nombre_rol", nullable = false, length = 80, unique = true)
    private String nombreRol;

    @Column(name = "descripcion", length = 250)
    private String descripcion;
}
