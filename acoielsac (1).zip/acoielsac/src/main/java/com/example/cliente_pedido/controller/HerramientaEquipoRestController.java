package com.example.cliente_pedido.controller;

import com.example.cliente_pedido.model.HerramientaEquipo;
import com.example.cliente_pedido.service.HerramientaEquipoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/herramienta-equipo")
public class HerramientaEquipoRestController {

    @Autowired
    private HerramientaEquipoService service;

    @GetMapping
    public Iterable<HerramientaEquipo> listar() {
        return service.readAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<HerramientaEquipo> buscarPorId(@PathVariable Long id) {
        return service.read(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public HerramientaEquipo crear(@RequestBody HerramientaEquipo obj) {
        return service.create(obj);
    }

    @PutMapping("/{id}")
    public ResponseEntity<HerramientaEquipo> actualizar(@PathVariable Long id, @RequestBody HerramientaEquipo obj) {
        return service.read(id)
                .map(existente -> ResponseEntity.ok(service.update(obj)))
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        if (service.read(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
