package com.example.cliente_pedido.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;
import java.time.LocalDate;

@Entity
@Table(name = "ORDEN_TRABAJO")
@Data @NoArgsConstructor @AllArgsConstructor
public class OrdenTrabajo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_orden_trabajo")
    private Long idOrdenTrabajo;

    @OneToOne
    @JoinColumn(name = "id_orden_compra", nullable = false, unique = true)
    private OrdenCompra ordenCompra;

    @ManyToOne
    @JoinColumn(name = "id_supervisor", nullable = false)
    private Empleado supervisor;

    @NotBlank
    @Column(name = "numero_ot", nullable = false, length = 50, unique = true)
    private String numeroOt;

    @Column(name = "fecha_programada")
    private LocalDate fechaProgramada;

    @Column(name = "hora_programada", length = 10)
    private String horaProgramada;

    @Column(name = "lugar_ejecucion", length = 250)
    private String lugarEjecucion;

    @Column(name = "croquis", length = 300)
    private String croquis;

    @Column(name = "estado_ot", nullable = false, length = 30)
    private String estadoOt = "ASIGNADA";
}
