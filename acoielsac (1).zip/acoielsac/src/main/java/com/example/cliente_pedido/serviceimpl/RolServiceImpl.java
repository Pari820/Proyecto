package com.example.cliente_pedido.serviceimpl;

import com.example.cliente_pedido.model.Rol;
import com.example.cliente_pedido.repository.RolRepository;
import com.example.cliente_pedido.service.RolService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class RolServiceImpl implements RolService {

    @Autowired
    private RolRepository repository;

    @Override
    public Rol create(Rol obj) {
        return repository.save(obj);
    }

    @Override
    public Rol update(Rol obj) {
        return repository.save(obj);
    }

    @Override
    public Optional<Rol> read(Long id) {
        return repository.findById(id);
    }

    @Override
    public void delete(Long id) {
        repository.deleteById(id);
    }

    @Override
    public Iterable<Rol> readAll() {
        return repository.findAll();
    }
}
