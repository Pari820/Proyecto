package com.example.cliente_pedido.controller;

import com.example.cliente_pedido.model.Cotizacion;
import com.example.cliente_pedido.model.OrdenCompra;
import com.example.cliente_pedido.service.CotizacionService;
import com.example.cliente_pedido.service.OrdenCompraService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.time.LocalDate;

@Controller
@RequestMapping("/ordencompra")
public class OrdenCompraController {

    @Autowired private OrdenCompraService service;
    @Autowired private CotizacionService cotizacionService;

    private boolean sinSesion(HttpSession s) { return s.getAttribute("usuarioId") == null; }

    @GetMapping
    public String listar(Model model, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        model.addAttribute("lista", service.readAll());
        return "ordencompra/lista";
    }

    @GetMapping("/nuevo")
    public String nuevo(Model model, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        OrdenCompra obj = new OrdenCompra();
        obj.setFechaEmision(LocalDate.now());
        model.addAttribute("obj", obj);
        model.addAttribute("cotizaciones", cotizacionService.readAll());
        return "ordencompra/form";
    }

    @PostMapping("/guardar")
    public String guardar(@ModelAttribute("obj") OrdenCompra obj,
                          Model model, RedirectAttributes ra, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        if (obj.getCotizacion() == null || obj.getCotizacion().getIdCotizacion() == null) {
            model.addAttribute("mensajeError", "Debe seleccionar una cotizacion.");
            model.addAttribute("cotizaciones", cotizacionService.readAll());
            return "ordencompra/form";
        }
        // Cargar la cotizacion completa
        Cotizacion cot = cotizacionService.read(obj.getCotizacion().getIdCotizacion()).orElse(null);
        if (cot == null) {
            model.addAttribute("mensajeError", "Cotizacion no encontrada.");
            model.addAttribute("cotizaciones", cotizacionService.readAll());
            return "ordencompra/form";
        }
        obj.setCotizacion(cot);
        service.create(obj);
        ra.addFlashAttribute("mensajeExito", "Orden de compra registrada correctamente.");
        return "redirect:/ordencompra";
    }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Long id, Model model, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        OrdenCompra obj = service.read(id).orElse(null);
        if (obj == null) return "redirect:/ordencompra";
        model.addAttribute("obj", obj);
        model.addAttribute("cotizaciones", cotizacionService.readAll());
        return "ordencompra/form";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id, RedirectAttributes ra, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        try {
            service.delete(id);
            ra.addFlashAttribute("mensajeExito", "Orden de compra eliminada.");
        } catch (Exception e) {
            ra.addFlashAttribute("mensajeError", "No se puede eliminar. Tiene registros asociados.");
        }
        return "redirect:/ordencompra";
    }
}
