package com.example.cliente_pedido.service;

import com.example.cliente_pedido.generic.CrudService;
import com.example.cliente_pedido.model.AtencionServicio;

public interface AtencionServicioService extends CrudService<AtencionServicio, Long> {
}
