package com.example.cliente_pedido.service;

import com.example.cliente_pedido.generic.CrudService;
import com.example.cliente_pedido.model.UsuarioRol;

public interface UsuarioRolService extends CrudService<UsuarioRol, Long> {
}
