package com.example.cliente_pedido.serviceimpl;

import com.example.cliente_pedido.model.AtsHerramienta;
import com.example.cliente_pedido.repository.AtsHerramientaRepository;
import com.example.cliente_pedido.service.AtsHerramientaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AtsHerramientaServiceImpl implements AtsHerramientaService {

    @Autowired
    private AtsHerramientaRepository repository;

    @Override
    public AtsHerramienta create(AtsHerramienta obj) {
        return repository.save(obj);
    }

    @Override
    public AtsHerramienta update(AtsHerramienta obj) {
        return repository.save(obj);
    }

    @Override
    public Optional<AtsHerramienta> read(Long id) {
        return repository.findById(id);
    }

    @Override
    public void delete(Long id) {
        repository.deleteById(id);
    }

    @Override
    public Iterable<AtsHerramienta> readAll() {
        return repository.findAll();
    }
}
