package com.example.cliente_pedido.controller;

import com.example.cliente_pedido.model.Iper;
import com.example.cliente_pedido.service.IperService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/iper")
public class IperRestController {

    @Autowired
    private IperService service;

    @GetMapping
    public Iterable<Iper> listar() {
        return service.readAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Iper> buscarPorId(@PathVariable Long id) {
        return service.read(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Iper crear(@RequestBody Iper obj) {
        return service.create(obj);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Iper> actualizar(@PathVariable Long id, @RequestBody Iper obj) {
        return service.read(id)
                .map(existente -> ResponseEntity.ok(service.update(obj)))
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        if (service.read(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
