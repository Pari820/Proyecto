package com.example.cliente_pedido.controller;

import com.example.cliente_pedido.model.Rol;
import com.example.cliente_pedido.service.RolService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/rol")
public class RolController {

    @Autowired private RolService service;

    private boolean sinSesion(HttpSession s) { return s.getAttribute("usuarioId") == null; }

    @GetMapping
    public String listar(Model model, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        model.addAttribute("lista", service.readAll());
        return "rol/lista";
    }

    @GetMapping("/nuevo")
    public String nuevo(Model model, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        model.addAttribute("obj", new Rol());
        return "rol/form";
    }

    @PostMapping("/guardar")
    public String guardar(@Valid @ModelAttribute("obj") Rol obj,
                          BindingResult result, RedirectAttributes ra, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        if (result.hasErrors()) return "rol/form";
        service.create(obj);
        ra.addFlashAttribute("mensajeExito", "Rol guardado correctamente.");
        return "redirect:/rol";
    }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Long id, Model model, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        Rol obj = service.read(id).orElse(null);
        if (obj == null) return "redirect:/rol";
        model.addAttribute("obj", obj);
        return "rol/form";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id, RedirectAttributes ra, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        try {
            service.delete(id);
            ra.addFlashAttribute("mensajeExito", "Rol eliminado.");
        } catch (Exception e) {
            ra.addFlashAttribute("mensajeError", "No se puede eliminar. Tiene registros asociados.");
        }
        return "redirect:/rol";
    }
}
