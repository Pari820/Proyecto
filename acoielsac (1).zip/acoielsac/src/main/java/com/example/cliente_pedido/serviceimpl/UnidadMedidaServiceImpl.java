package com.example.cliente_pedido.serviceimpl;

import com.example.cliente_pedido.model.UnidadMedida;
import com.example.cliente_pedido.repository.UnidadMedidaRepository;
import com.example.cliente_pedido.service.UnidadMedidaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UnidadMedidaServiceImpl implements UnidadMedidaService {

    @Autowired
    private UnidadMedidaRepository repository;

    @Override
    public UnidadMedida create(UnidadMedida obj) {
        return repository.save(obj);
    }

    @Override
    public UnidadMedida update(UnidadMedida obj) {
        return repository.save(obj);
    }

    @Override
    public Optional<UnidadMedida> read(Long id) {
        return repository.findById(id);
    }

    @Override
    public void delete(Long id) {
        repository.deleteById(id);
    }

    @Override
    public Iterable<UnidadMedida> readAll() {
        return repository.findAll();
    }
}
