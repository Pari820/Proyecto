package com.example.cliente_pedido.serviceimpl;

import com.example.cliente_pedido.model.Cargo;
import com.example.cliente_pedido.repository.CargoRepository;
import com.example.cliente_pedido.service.CargoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class CargoServiceImpl implements CargoService {

    @Autowired
    private CargoRepository repository;

    @Override
    public Cargo create(Cargo obj) {
        return repository.save(obj);
    }

    @Override
    public Cargo update(Cargo obj) {
        return repository.save(obj);
    }

    @Override
    public Optional<Cargo> read(Long id) {
        return repository.findById(id);
    }

    @Override
    public void delete(Long id) {
        repository.deleteById(id);
    }

    @Override
    public Iterable<Cargo> readAll() {
        return repository.findAll();
    }
}
