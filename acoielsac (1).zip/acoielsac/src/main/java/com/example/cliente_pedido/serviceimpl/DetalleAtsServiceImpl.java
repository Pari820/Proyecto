package com.example.cliente_pedido.serviceimpl;

import com.example.cliente_pedido.model.DetalleAts;
import com.example.cliente_pedido.repository.DetalleAtsRepository;
import com.example.cliente_pedido.service.DetalleAtsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class DetalleAtsServiceImpl implements DetalleAtsService {

    @Autowired
    private DetalleAtsRepository repository;

    @Override
    public DetalleAts create(DetalleAts obj) {
        return repository.save(obj);
    }

    @Override
    public DetalleAts update(DetalleAts obj) {
        return repository.save(obj);
    }

    @Override
    public Optional<DetalleAts> read(Long id) {
        return repository.findById(id);
    }

    @Override
    public void delete(Long id) {
        repository.deleteById(id);
    }

    @Override
    public Iterable<DetalleAts> readAll() {
        return repository.findAll();
    }
}
