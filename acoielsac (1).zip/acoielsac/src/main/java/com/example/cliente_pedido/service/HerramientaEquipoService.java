package com.example.cliente_pedido.service;

import com.example.cliente_pedido.generic.CrudService;
import com.example.cliente_pedido.model.HerramientaEquipo;

public interface HerramientaEquipoService extends CrudService<HerramientaEquipo, Long> {
}
