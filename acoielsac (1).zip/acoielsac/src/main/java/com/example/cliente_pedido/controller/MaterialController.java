package com.example.cliente_pedido.controller;

import com.example.cliente_pedido.model.Material;
import com.example.cliente_pedido.service.MaterialService;
import com.example.cliente_pedido.service.UnidadMedidaService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.math.BigDecimal;

@Controller
@RequestMapping("/material")
public class MaterialController {

    @Autowired private MaterialService service;
    @Autowired private UnidadMedidaService unidadMedidaService;

    private boolean sinSesion(HttpSession s) { return s.getAttribute("usuarioId") == null; }

    @GetMapping
    public String listar(Model model, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        model.addAttribute("lista", service.readAll());
        return "material/lista";
    }

    @GetMapping("/nuevo")
    public String nuevo(Model model, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        Material obj = new Material();
        obj.setStockActual(BigDecimal.ZERO);
        obj.setStockMinimo(BigDecimal.ZERO);
        obj.setEstadoMaterial("ACTIVO");
        model.addAttribute("obj", obj);
        model.addAttribute("unidades", unidadMedidaService.readAll());
        return "material/form";
    }

    @PostMapping("/guardar")
    public String guardar(@ModelAttribute("obj") Material obj,
                          Model model, RedirectAttributes ra, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        if (obj.getStockActual() != null && obj.getStockActual().compareTo(BigDecimal.ZERO) < 0) {
            model.addAttribute("mensajeError", "El stock no puede ser negativo.");
            model.addAttribute("unidades", unidadMedidaService.readAll());
            return "material/form";
        }
        if (obj.getEstadoMaterial() == null) obj.setEstadoMaterial("ACTIVO");
        service.create(obj);
        ra.addFlashAttribute("mensajeExito", "Material guardado correctamente.");
        return "redirect:/material";
    }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Long id, Model model, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        Material obj = service.read(id).orElse(null);
        if (obj == null) return "redirect:/material";
        model.addAttribute("obj", obj);
        model.addAttribute("unidades", unidadMedidaService.readAll());
        return "material/form";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id, RedirectAttributes ra, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        try { service.delete(id); ra.addFlashAttribute("mensajeExito", "Material eliminado."); }
        catch (Exception e) { ra.addFlashAttribute("mensajeError", "No se puede eliminar. Tiene movimientos asociados."); }
        return "redirect:/material";
    }
}
