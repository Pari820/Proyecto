package com.example.cliente_pedido.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity
@Table(name = "ATENCION_SERVICIO")
@Data @NoArgsConstructor @AllArgsConstructor
public class AtencionServicio {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_atencion")
    private Long idAtencion;

    @OneToOne
    @JoinColumn(name = "id_orden_trabajo", nullable = false, unique = true)
    private OrdenTrabajo ordenTrabajo;

    @Column(name = "fecha_registro", nullable = false)
    private LocalDate fechaRegistro = LocalDate.now();

    @Column(name = "descripcion_trabajo_realizado", length = 700)
    private String descripcionTrabajoRealizado;

    @Column(name = "observaciones", length = 700)
    private String observaciones;

    @Column(name = "mediciones", length = 500)
    private String mediciones;

    @Column(name = "fecha_hora_registro", nullable = false)
    private LocalDateTime fechaHoraRegistro = LocalDateTime.now();
}
