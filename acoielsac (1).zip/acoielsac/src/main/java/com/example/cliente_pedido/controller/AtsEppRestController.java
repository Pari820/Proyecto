package com.example.cliente_pedido.controller;

import com.example.cliente_pedido.model.AtsEpp;
import com.example.cliente_pedido.service.AtsEppService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/ats-epp")
public class AtsEppRestController {

    @Autowired
    private AtsEppService service;

    @GetMapping
    public Iterable<AtsEpp> listar() {
        return service.readAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<AtsEpp> buscarPorId(@PathVariable Long id) {
        return service.read(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public AtsEpp crear(@RequestBody AtsEpp obj) {
        return service.create(obj);
    }

    @PutMapping("/{id}")
    public ResponseEntity<AtsEpp> actualizar(@PathVariable Long id, @RequestBody AtsEpp obj) {
        return service.read(id)
                .map(existente -> ResponseEntity.ok(service.update(obj)))
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        if (service.read(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
