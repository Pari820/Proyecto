package com.example.cliente_pedido.service;

import com.example.cliente_pedido.generic.CrudService;
import com.example.cliente_pedido.model.Empleado;

public interface EmpleadoService extends CrudService<Empleado, Long> {
}
