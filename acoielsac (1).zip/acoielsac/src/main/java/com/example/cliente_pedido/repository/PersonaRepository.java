package com.example.cliente_pedido.repository;

import com.example.cliente_pedido.model.Persona;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface PersonaRepository extends JpaRepository<Persona, Long> {
    Optional<Persona> findByTipoDocumentoAndNroDocumento(String tipoDocumento, String nroDocumento);
}
