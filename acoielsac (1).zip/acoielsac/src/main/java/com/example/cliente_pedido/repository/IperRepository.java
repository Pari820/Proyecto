package com.example.cliente_pedido.repository;

import com.example.cliente_pedido.model.Iper;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface IperRepository extends JpaRepository<Iper, Long> {
}
