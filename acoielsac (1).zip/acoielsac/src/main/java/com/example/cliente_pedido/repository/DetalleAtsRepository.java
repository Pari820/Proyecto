package com.example.cliente_pedido.repository;

import com.example.cliente_pedido.model.DetalleAts;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DetalleAtsRepository extends JpaRepository<DetalleAts, Long> {
}
