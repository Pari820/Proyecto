package com.example.cliente_pedido.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

@Entity
@Table(name = "ACCESO")
@Data @NoArgsConstructor @AllArgsConstructor
public class Acceso {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_acceso")
    private Long idAcceso;

    @NotBlank
    @Column(name = "nombre_modulo", nullable = false, length = 100, unique = true)
    private String nombreModulo;

    @Column(name = "descripcion_acceso", length = 250)
    private String descripcionAcceso;
}
