package com.example.cliente_pedido.serviceimpl;

import com.example.cliente_pedido.model.UsuarioRol;
import com.example.cliente_pedido.repository.UsuarioRolRepository;
import com.example.cliente_pedido.service.UsuarioRolService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UsuarioRolServiceImpl implements UsuarioRolService {

    @Autowired
    private UsuarioRolRepository repository;

    @Override
    public UsuarioRol create(UsuarioRol obj) {
        return repository.save(obj);
    }

    @Override
    public UsuarioRol update(UsuarioRol obj) {
        return repository.save(obj);
    }

    @Override
    public Optional<UsuarioRol> read(Long id) {
        return repository.findById(id);
    }

    @Override
    public void delete(Long id) {
        repository.deleteById(id);
    }

    @Override
    public Iterable<UsuarioRol> readAll() {
        return repository.findAll();
    }
}
