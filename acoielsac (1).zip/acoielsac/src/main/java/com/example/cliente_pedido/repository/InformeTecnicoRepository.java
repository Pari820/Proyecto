package com.example.cliente_pedido.repository;

import com.example.cliente_pedido.model.InformeTecnico;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface InformeTecnicoRepository extends JpaRepository<InformeTecnico, Long> {
}
