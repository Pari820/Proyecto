package com.example.cliente_pedido.model;

import jakarta.persistence.*;
import lombok.*;
import java.math.BigDecimal;
import java.time.LocalDate;

@Entity
@Table(name = "COTIZACION")
@Data @NoArgsConstructor @AllArgsConstructor
public class Cotizacion {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_cotizacion")
    private Long idCotizacion;

    @ManyToOne
    @JoinColumn(name = "id_solicitud", nullable = false)
    private SolicitudServicio solicitudServicio;

    @Column(name = "fecha_cotizacion", nullable = false)
    private LocalDate fechaCotizacion = LocalDate.now();

    @Column(name = "descripcion_trabajo", length = 500)
    private String descripcionTrabajo;

    @Column(name = "monto_estimado", nullable = false, precision = 12, scale = 2)
    private BigDecimal montoEstimado;

    @Column(name = "observaciones", length = 500)
    private String observaciones;

    @Column(name = "estado_cotizacion", nullable = false, length = 30)
    private String estadoCotizacion = "EMITIDA";
}
