package com.example.cliente_pedido.serviceimpl;

import com.example.cliente_pedido.model.UsoSistema;
import com.example.cliente_pedido.repository.UsoSistemaRepository;
import com.example.cliente_pedido.service.UsoSistemaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UsoSistemaServiceImpl implements UsoSistemaService {

    @Autowired
    private UsoSistemaRepository repository;

    @Override
    public UsoSistema create(UsoSistema obj) {
        return repository.save(obj);
    }

    @Override
    public UsoSistema update(UsoSistema obj) {
        return repository.save(obj);
    }

    @Override
    public Optional<UsoSistema> read(Long id) {
        return repository.findById(id);
    }

    @Override
    public void delete(Long id) {
        repository.deleteById(id);
    }

    @Override
    public Iterable<UsoSistema> readAll() {
        return repository.findAll();
    }
}
