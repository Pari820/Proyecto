package com.example.cliente_pedido.service;

import com.example.cliente_pedido.generic.CrudService;
import com.example.cliente_pedido.model.OrdenTrabajo;

public interface OrdenTrabajoService extends CrudService<OrdenTrabajo, Long> {
}
