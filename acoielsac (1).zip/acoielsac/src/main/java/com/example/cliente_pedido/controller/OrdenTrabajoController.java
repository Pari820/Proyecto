package com.example.cliente_pedido.controller;

import com.example.cliente_pedido.model.OrdenTrabajo;
import com.example.cliente_pedido.service.EmpleadoService;
import com.example.cliente_pedido.service.OrdenCompraService;
import com.example.cliente_pedido.service.OrdenTrabajoService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/ordentrabajo")
public class OrdenTrabajoController {

    @Autowired private OrdenTrabajoService service;
    @Autowired private OrdenCompraService ordenCompraService;
    @Autowired private EmpleadoService empleadoService;

    private boolean sinSesion(HttpSession s) { return s.getAttribute("usuarioId") == null; }

    @GetMapping
    public String listar(Model model, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        model.addAttribute("lista", service.readAll());
        return "ordentrabajo/lista";
    }

    @GetMapping("/nuevo")
    public String nuevo(Model model, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        OrdenTrabajo obj = new OrdenTrabajo();
        obj.setEstadoOt("ASIGNADA");
        model.addAttribute("obj", obj);
        model.addAttribute("ordenesCompra", ordenCompraService.readAll());
        model.addAttribute("empleados", empleadoService.readAll());
        return "ordentrabajo/form";
    }

    @PostMapping("/guardar")
    public String guardar(@ModelAttribute("obj") OrdenTrabajo obj,
                          Model model, RedirectAttributes ra, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        if (obj.getEstadoOt() == null) obj.setEstadoOt("ASIGNADA");
        service.create(obj);
        ra.addFlashAttribute("mensajeExito", "Orden de trabajo registrada.");
        return "redirect:/ordentrabajo";
    }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Long id, Model model, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        OrdenTrabajo obj = service.read(id).orElse(null);
        if (obj == null) return "redirect:/ordentrabajo";
        model.addAttribute("obj", obj);
        model.addAttribute("ordenesCompra", ordenCompraService.readAll());
        model.addAttribute("empleados", empleadoService.readAll());
        return "ordentrabajo/form";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id, RedirectAttributes ra, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        try {
            service.delete(id);
            ra.addFlashAttribute("mensajeExito", "Orden de trabajo eliminada.");
        } catch (Exception e) {
            ra.addFlashAttribute("mensajeError", "No se puede eliminar. Tiene registros asociados.");
        }
        return "redirect:/ordentrabajo";
    }
}
