package com.example.cliente_pedido.service;

import com.example.cliente_pedido.generic.CrudService;
import com.example.cliente_pedido.model.RolAcceso;

public interface RolAccesoService extends CrudService<RolAcceso, Long> {
}
