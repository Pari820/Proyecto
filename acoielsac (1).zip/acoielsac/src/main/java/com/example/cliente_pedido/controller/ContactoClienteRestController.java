package com.example.cliente_pedido.controller;

import com.example.cliente_pedido.model.ContactoCliente;
import com.example.cliente_pedido.service.ContactoClienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/contacto-cliente")
public class ContactoClienteRestController {

    @Autowired
    private ContactoClienteService service;

    @GetMapping
    public Iterable<ContactoCliente> listar() {
        return service.readAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<ContactoCliente> buscarPorId(@PathVariable Long id) {
        return service.read(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public ContactoCliente crear(@RequestBody ContactoCliente obj) {
        return service.create(obj);
    }

    @PutMapping("/{id}")
    public ResponseEntity<ContactoCliente> actualizar(@PathVariable Long id, @RequestBody ContactoCliente obj) {
        return service.read(id)
                .map(existente -> ResponseEntity.ok(service.update(obj)))
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        if (service.read(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
