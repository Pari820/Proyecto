package com.example.cliente_pedido.service;

import com.example.cliente_pedido.generic.CrudService;
import com.example.cliente_pedido.model.Cargo;

public interface CargoService extends CrudService<Cargo, Long> {
}
