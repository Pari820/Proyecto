package com.example.cliente_pedido.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

@Entity
@Table(name = "HERRAMIENTA_EQUIPO")
@Data @NoArgsConstructor @AllArgsConstructor
public class HerramientaEquipo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_herramienta")
    private Long idHerramienta;

    @NotBlank
    @Column(name = "nombre_herramienta", nullable = false, length = 120, unique = true)
    private String nombreHerramienta;

    @Column(name = "descripcion", length = 250)
    private String descripcion;
}
