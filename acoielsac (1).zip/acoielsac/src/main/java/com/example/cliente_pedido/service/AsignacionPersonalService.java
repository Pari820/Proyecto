package com.example.cliente_pedido.service;

import com.example.cliente_pedido.generic.CrudService;
import com.example.cliente_pedido.model.AsignacionPersonal;

public interface AsignacionPersonalService extends CrudService<AsignacionPersonal, Long> {
}
