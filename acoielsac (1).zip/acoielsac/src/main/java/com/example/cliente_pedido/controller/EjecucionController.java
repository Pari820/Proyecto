package com.example.cliente_pedido.controller;

import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class EjecucionController {

    @GetMapping("/ejecucion")
    public String ejecucion(HttpSession session) {
        if (session.getAttribute("usuarioId") == null) return "redirect:/login";
        return "ejecucion";
    }

    @GetMapping("/conformidad")
    public String conformidad(HttpSession session) {
        if (session.getAttribute("usuarioId") == null) return "redirect:/login";
        return "conformidad";
    }
}
