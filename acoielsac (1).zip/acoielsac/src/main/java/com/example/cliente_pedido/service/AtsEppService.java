package com.example.cliente_pedido.service;

import com.example.cliente_pedido.generic.CrudService;
import com.example.cliente_pedido.model.AtsEpp;

public interface AtsEppService extends CrudService<AtsEpp, Long> {
}
