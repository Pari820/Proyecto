package com.example.cliente_pedido.serviceimpl;

import com.example.cliente_pedido.model.EvidenciaFotografica;
import com.example.cliente_pedido.repository.EvidenciaFotograficaRepository;
import com.example.cliente_pedido.service.EvidenciaFotograficaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class EvidenciaFotograficaServiceImpl implements EvidenciaFotograficaService {

    @Autowired
    private EvidenciaFotograficaRepository repository;

    @Override
    public EvidenciaFotografica create(EvidenciaFotografica obj) {
        return repository.save(obj);
    }

    @Override
    public EvidenciaFotografica update(EvidenciaFotografica obj) {
        return repository.save(obj);
    }

    @Override
    public Optional<EvidenciaFotografica> read(Long id) {
        return repository.findById(id);
    }

    @Override
    public void delete(Long id) {
        repository.deleteById(id);
    }

    @Override
    public Iterable<EvidenciaFotografica> readAll() {
        return repository.findAll();
    }
}
