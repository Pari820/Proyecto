package com.example.cliente_pedido.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "ATS_EPP", uniqueConstraints = @UniqueConstraint(columnNames = {"id_ats", "id_epp"}))
@Data @NoArgsConstructor @AllArgsConstructor
public class AtsEpp {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_ats_epp")
    private Long idAtsEpp;

    @ManyToOne
    @JoinColumn(name = "id_ats", nullable = false)
    private Ats ats;

    @ManyToOne
    @JoinColumn(name = "id_epp", nullable = false)
    private Epp epp;
}
