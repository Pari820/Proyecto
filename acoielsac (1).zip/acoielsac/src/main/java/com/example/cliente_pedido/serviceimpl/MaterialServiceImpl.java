package com.example.cliente_pedido.serviceimpl;

import com.example.cliente_pedido.model.Material;
import com.example.cliente_pedido.repository.MaterialRepository;
import com.example.cliente_pedido.service.MaterialService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class MaterialServiceImpl implements MaterialService {

    @Autowired
    private MaterialRepository repository;

    @Override
    public Material create(Material obj) {
        return repository.save(obj);
    }

    @Override
    public Material update(Material obj) {
        return repository.save(obj);
    }

    @Override
    public Optional<Material> read(Long id) {
        return repository.findById(id);
    }

    @Override
    public void delete(Long id) {
        repository.deleteById(id);
    }

    @Override
    public Iterable<Material> readAll() {
        return repository.findAll();
    }
}
