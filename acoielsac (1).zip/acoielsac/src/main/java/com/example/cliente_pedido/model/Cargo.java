package com.example.cliente_pedido.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

@Entity
@Table(name = "CARGO")
@Data @NoArgsConstructor @AllArgsConstructor
public class Cargo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_cargo")
    private Long idCargo;

    @NotBlank
    @Column(name = "nombre_cargo", nullable = false, length = 80, unique = true)
    private String nombreCargo;
}
