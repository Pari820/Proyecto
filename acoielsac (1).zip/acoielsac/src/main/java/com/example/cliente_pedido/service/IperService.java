package com.example.cliente_pedido.service;

import com.example.cliente_pedido.generic.CrudService;
import com.example.cliente_pedido.model.Iper;

public interface IperService extends CrudService<Iper, Long> {
}
