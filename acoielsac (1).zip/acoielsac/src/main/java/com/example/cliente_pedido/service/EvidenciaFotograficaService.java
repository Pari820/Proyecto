package com.example.cliente_pedido.service;

import com.example.cliente_pedido.generic.CrudService;
import com.example.cliente_pedido.model.EvidenciaFotografica;

public interface EvidenciaFotograficaService extends CrudService<EvidenciaFotografica, Long> {
}
