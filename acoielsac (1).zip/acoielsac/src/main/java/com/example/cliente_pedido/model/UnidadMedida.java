package com.example.cliente_pedido.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

@Entity
@Table(name = "UNIDAD_MEDIDA")
@Data @NoArgsConstructor @AllArgsConstructor
public class UnidadMedida {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_unidad_medida")
    private Long idUnidadMedida;

    @NotBlank
    @Column(name = "nombre_unidad", nullable = false, length = 80, unique = true)
    private String nombreUnidad;

    @NotBlank
    @Column(name = "abreviatura", nullable = false, length = 20)
    private String abreviatura;
}
