package com.example.cliente_pedido.controller;
import com.example.cliente_pedido.model.Especialidad;
import com.example.cliente_pedido.service.EspecialidadService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/especialidad")
public class EspecialidadController {
    @Autowired private EspecialidadService service;
    private boolean sinSesion(HttpSession s) { return s.getAttribute("usuarioId") == null; }
    @GetMapping public String listar(Model m, HttpSession s) {
        if(sinSesion(s)) return "redirect:/login";
        m.addAttribute("lista", service.readAll()); return "especialidad/lista"; }
    @GetMapping("/nuevo") public String nuevo(Model m, HttpSession s) {
        if(sinSesion(s)) return "redirect:/login";
        m.addAttribute("obj", new Especialidad()); return "especialidad/form"; }
    @PostMapping("/guardar") public String guardar(@Valid @ModelAttribute("obj") Especialidad obj, BindingResult r, RedirectAttributes ra, HttpSession s) {
        if(sinSesion(s)) return "redirect:/login";
        if(r.hasErrors()) return "especialidad/form";
        service.create(obj); ra.addFlashAttribute("mensajeExito","Especialidad guardada."); return "redirect:/especialidad"; }
    @GetMapping("/editar/{id}") public String editar(@PathVariable Long id, Model m, HttpSession s) {
        if(sinSesion(s)) return "redirect:/login";
        Especialidad obj = service.read(id).orElse(null); if(obj==null) return "redirect:/especialidad";
        m.addAttribute("obj",obj); return "especialidad/form"; }
    @GetMapping("/eliminar/{id}") public String eliminar(@PathVariable Long id, RedirectAttributes ra, HttpSession s) {
        if(sinSesion(s)) return "redirect:/login";
        try { service.delete(id); ra.addFlashAttribute("mensajeExito","Especialidad eliminada."); }
        catch(Exception e) { ra.addFlashAttribute("mensajeError","No se puede eliminar."); }
        return "redirect:/especialidad"; }
}
