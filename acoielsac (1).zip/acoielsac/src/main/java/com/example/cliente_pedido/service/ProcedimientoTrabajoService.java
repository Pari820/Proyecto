package com.example.cliente_pedido.service;

import com.example.cliente_pedido.generic.CrudService;
import com.example.cliente_pedido.model.ProcedimientoTrabajo;

public interface ProcedimientoTrabajoService extends CrudService<ProcedimientoTrabajo, Long> {
}
