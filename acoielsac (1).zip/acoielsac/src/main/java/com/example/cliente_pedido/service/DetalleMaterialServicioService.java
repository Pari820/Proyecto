package com.example.cliente_pedido.service;

import com.example.cliente_pedido.generic.CrudService;
import com.example.cliente_pedido.model.DetalleMaterialServicio;

public interface DetalleMaterialServicioService extends CrudService<DetalleMaterialServicio, Long> {
}
