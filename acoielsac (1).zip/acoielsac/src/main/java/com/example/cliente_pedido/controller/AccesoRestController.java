package com.example.cliente_pedido.controller;

import com.example.cliente_pedido.model.Acceso;
import com.example.cliente_pedido.service.AccesoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/acceso")
public class AccesoRestController {

    @Autowired
    private AccesoService service;

    @GetMapping
    public Iterable<Acceso> listar() {
        return service.readAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Acceso> buscarPorId(@PathVariable Long id) {
        return service.read(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Acceso crear(@RequestBody Acceso obj) {
        return service.create(obj);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Acceso> actualizar(@PathVariable Long id, @RequestBody Acceso obj) {
        return service.read(id)
                .map(existente -> ResponseEntity.ok(service.update(obj)))
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        if (service.read(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
