package com.example.cliente_pedido.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

@Entity
@Table(name = "INFORME_TECNICO")
@Data @NoArgsConstructor @AllArgsConstructor
public class InformeTecnico {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_informe")
    private Long idInforme;

    @OneToOne
    @JoinColumn(name = "id_atencion", nullable = false, unique = true)
    private AtencionServicio atencionServicio;

    @Column(name = "fecha_elaboracion", nullable = false)
    private LocalDate fechaElaboracion = LocalDate.now();

    @Column(name = "descripcion_informe", length = 1000)
    private String descripcionInforme;

    @Column(name = "conclusiones", length = 700)
    private String conclusiones;

    @Column(name = "fecha_envio_cliente")
    private LocalDate fechaEnvioCliente;
}
