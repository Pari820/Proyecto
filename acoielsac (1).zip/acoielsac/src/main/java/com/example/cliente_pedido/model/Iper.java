package com.example.cliente_pedido.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

@Entity
@Table(name = "IPER")
@Data @NoArgsConstructor @AllArgsConstructor
public class Iper {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_iper")
    private Long idIper;

    @OneToOne
    @JoinColumn(name = "id_orden_trabajo", nullable = false, unique = true)
    private OrdenTrabajo ordenTrabajo;

    @Column(name = "fecha_registro", nullable = false)
    private LocalDate fechaRegistro = LocalDate.now();

    @Column(name = "archivo_iper", length = 300)
    private String archivoIper;

    @Column(name = "observaciones", length = 500)
    private String observaciones;

    @Column(name = "estado_aprobacion_cliente", nullable = false, length = 30)
    private String estadoAprobacionCliente = "PENDIENTE";
}
