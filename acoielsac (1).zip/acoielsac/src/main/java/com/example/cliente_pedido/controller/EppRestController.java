package com.example.cliente_pedido.controller;

import com.example.cliente_pedido.model.Epp;
import com.example.cliente_pedido.service.EppService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/epp")
public class EppRestController {

    @Autowired
    private EppService service;

    @GetMapping
    public Iterable<Epp> listar() {
        return service.readAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<Epp> buscarPorId(@PathVariable Long id) {
        return service.read(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public Epp crear(@RequestBody Epp obj) {
        return service.create(obj);
    }

    @PutMapping("/{id}")
    public ResponseEntity<Epp> actualizar(@PathVariable Long id, @RequestBody Epp obj) {
        return service.read(id)
                .map(existente -> ResponseEntity.ok(service.update(obj)))
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        if (service.read(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
