package com.example.cliente_pedido.controller;

import com.example.cliente_pedido.model.EvidenciaFotografica;
import com.example.cliente_pedido.service.EvidenciaFotograficaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/evidencia-fotografica")
public class EvidenciaFotograficaRestController {

    @Autowired
    private EvidenciaFotograficaService service;

    @GetMapping
    public Iterable<EvidenciaFotografica> listar() {
        return service.readAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<EvidenciaFotografica> buscarPorId(@PathVariable Long id) {
        return service.read(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public EvidenciaFotografica crear(@RequestBody EvidenciaFotografica obj) {
        return service.create(obj);
    }

    @PutMapping("/{id}")
    public ResponseEntity<EvidenciaFotografica> actualizar(@PathVariable Long id, @RequestBody EvidenciaFotografica obj) {
        return service.read(id)
                .map(existente -> ResponseEntity.ok(service.update(obj)))
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        if (service.read(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
