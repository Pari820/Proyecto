package com.example.cliente_pedido.service;

import com.example.cliente_pedido.generic.CrudService;
import com.example.cliente_pedido.model.TipoServicio;

public interface TipoServicioService extends CrudService<TipoServicio, Long> {
}
