package com.example.cliente_pedido.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "CONTACTO_CLIENTE")
@Data @NoArgsConstructor @AllArgsConstructor
public class ContactoCliente {
    @Id
    @Column(name = "id_persona")
    private Long idPersona;

    @OneToOne
    @MapsId
    @JoinColumn(name = "id_persona")
    private Persona persona;

    @ManyToOne
    @JoinColumn(name = "id_cliente", nullable = false)
    private Cliente cliente;

    @Column(name = "cargo_contacto", length = 100)
    private String cargoContacto;
}
