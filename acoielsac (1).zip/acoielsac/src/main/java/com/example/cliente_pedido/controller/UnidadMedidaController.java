package com.example.cliente_pedido.controller;
import com.example.cliente_pedido.model.UnidadMedida;
import com.example.cliente_pedido.service.UnidadMedidaService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/unidadmedida")
public class UnidadMedidaController {
    @Autowired private UnidadMedidaService service;
    private boolean sinSesion(HttpSession s) { return s.getAttribute("usuarioId") == null; }
    @GetMapping public String listar(Model m, HttpSession s) {
        if(sinSesion(s)) return "redirect:/login";
        m.addAttribute("lista", service.readAll()); return "unidadmedida/lista"; }
    @GetMapping("/nuevo") public String nuevo(Model m, HttpSession s) {
        if(sinSesion(s)) return "redirect:/login";
        m.addAttribute("obj", new UnidadMedida()); return "unidadmedida/form"; }
    @PostMapping("/guardar") public String guardar(@Valid @ModelAttribute("obj") UnidadMedida obj, BindingResult r, RedirectAttributes ra, HttpSession s) {
        if(sinSesion(s)) return "redirect:/login";
        if(r.hasErrors()) return "unidadmedida/form";
        service.create(obj); ra.addFlashAttribute("mensajeExito","Unidad guardada."); return "redirect:/unidadmedida"; }
    @GetMapping("/editar/{id}") public String editar(@PathVariable Long id, Model m, HttpSession s) {
        if(sinSesion(s)) return "redirect:/login";
        UnidadMedida obj = service.read(id).orElse(null); if(obj==null) return "redirect:/unidadmedida";
        m.addAttribute("obj",obj); return "unidadmedida/form"; }
    @GetMapping("/eliminar/{id}") public String eliminar(@PathVariable Long id, RedirectAttributes ra, HttpSession s) {
        if(sinSesion(s)) return "redirect:/login";
        try { service.delete(id); ra.addFlashAttribute("mensajeExito","Unidad eliminada."); }
        catch(Exception e) { ra.addFlashAttribute("mensajeError","No se puede eliminar."); }
        return "redirect:/unidadmedida"; }
}
