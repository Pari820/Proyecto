package com.example.cliente_pedido.controller;

import jakarta.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class LoginController {

    @GetMapping("/")
    public String raiz() {
        return "redirect:/login";
    }

    @GetMapping("/login")
    public String loginForm(HttpSession session) {
        if (session.getAttribute("usuarioId") != null) {
            return "redirect:/inicio";
        }
        return "login/login";
    }

    @PostMapping("/login")
    public String loginProcesar(
            @RequestParam(value = "nombreUsuario", required = false) String nombreUsuario,
            @RequestParam(value = "contrasena", required = false) String contrasena,
            HttpSession session) {

        /*
         * ACCESO LIBRE PARA PRUEBAS ACADÉMICAS
         * --------------------------------------------------
         * Con esta configuración, el sistema permite iniciar sesión
         * con cualquier usuario y cualquier contraseña.
         *
         * No consulta la tabla USUARIO ni valida la contraseña.
         * Cuando se quiera volver a validar contra la base de datos,
         * reemplazar este método por la lógica original del login.
         */

        String usuarioIngresado = nombreUsuario == null || nombreUsuario.trim().isEmpty()
                ? "Invitado"
                : nombreUsuario.trim();

        session.setAttribute("usuarioId", 1L);
        session.setAttribute("usuarioNombre", usuarioIngresado);
        session.setAttribute("usuarioInicial", usuarioIngresado.substring(0, 1).toUpperCase());
        session.setAttribute("modoPrueba", true);

        return "redirect:/inicio";
    }

    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }

    @GetMapping("/inicio")
    public String inicio(HttpSession session) {
        if (session.getAttribute("usuarioId") == null) {
            return "redirect:/login";
        }
        return "inicio";
    }
}
