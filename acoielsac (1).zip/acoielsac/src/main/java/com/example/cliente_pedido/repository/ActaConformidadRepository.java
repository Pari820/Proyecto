package com.example.cliente_pedido.repository;

import com.example.cliente_pedido.model.ActaConformidad;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ActaConformidadRepository extends JpaRepository<ActaConformidad, Long> {
}
