package com.example.cliente_pedido.serviceimpl;

import com.example.cliente_pedido.model.AtsEpp;
import com.example.cliente_pedido.repository.AtsEppRepository;
import com.example.cliente_pedido.service.AtsEppService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AtsEppServiceImpl implements AtsEppService {

    @Autowired
    private AtsEppRepository repository;

    @Override
    public AtsEpp create(AtsEpp obj) {
        return repository.save(obj);
    }

    @Override
    public AtsEpp update(AtsEpp obj) {
        return repository.save(obj);
    }

    @Override
    public Optional<AtsEpp> read(Long id) {
        return repository.findById(id);
    }

    @Override
    public void delete(Long id) {
        repository.deleteById(id);
    }

    @Override
    public Iterable<AtsEpp> readAll() {
        return repository.findAll();
    }
}
