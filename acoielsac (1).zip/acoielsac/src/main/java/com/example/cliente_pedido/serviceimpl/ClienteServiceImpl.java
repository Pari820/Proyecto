package com.example.cliente_pedido.serviceimpl;

import com.example.cliente_pedido.model.Cliente;
import com.example.cliente_pedido.repository.ClienteRepository;
import com.example.cliente_pedido.service.ClienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ClienteServiceImpl implements ClienteService {

    @Autowired
    private ClienteRepository repository;

    @Override
    public Cliente create(Cliente obj) {
        return repository.save(obj);
    }

    @Override
    public Cliente update(Cliente obj) {
        return repository.save(obj);
    }

    @Override
    public Optional<Cliente> read(Long id) {
        return repository.findById(id);
    }

    @Override
    public void delete(Long id) {
        repository.deleteById(id);
    }

    @Override
    public Iterable<Cliente> readAll() {
        return repository.findAll();
    }
}
