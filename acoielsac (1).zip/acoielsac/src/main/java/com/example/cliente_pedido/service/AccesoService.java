package com.example.cliente_pedido.service;

import com.example.cliente_pedido.generic.CrudService;
import com.example.cliente_pedido.model.Acceso;

public interface AccesoService extends CrudService<Acceso, Long> {
}
