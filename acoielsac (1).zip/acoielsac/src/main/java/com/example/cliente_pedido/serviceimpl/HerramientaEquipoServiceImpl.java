package com.example.cliente_pedido.serviceimpl;

import com.example.cliente_pedido.model.HerramientaEquipo;
import com.example.cliente_pedido.repository.HerramientaEquipoRepository;
import com.example.cliente_pedido.service.HerramientaEquipoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class HerramientaEquipoServiceImpl implements HerramientaEquipoService {

    @Autowired
    private HerramientaEquipoRepository repository;

    @Override
    public HerramientaEquipo create(HerramientaEquipo obj) {
        return repository.save(obj);
    }

    @Override
    public HerramientaEquipo update(HerramientaEquipo obj) {
        return repository.save(obj);
    }

    @Override
    public Optional<HerramientaEquipo> read(Long id) {
        return repository.findById(id);
    }

    @Override
    public void delete(Long id) {
        repository.deleteById(id);
    }

    @Override
    public Iterable<HerramientaEquipo> readAll() {
        return repository.findAll();
    }
}
