package com.example.cliente_pedido.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;
import java.time.LocalDate;

@Entity
@Table(name = "EVIDENCIA_FOTOGRAFICA")
@Data @NoArgsConstructor @AllArgsConstructor
public class EvidenciaFotografica {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_foto")
    private Long idFoto;

    @ManyToOne
    @JoinColumn(name = "id_informe", nullable = false)
    private InformeTecnico informeTecnico;

    @NotBlank
    @Column(name = "tipo_evidencia", nullable = false, length = 20)
    private String tipoEvidencia;

    @NotBlank
    @Column(name = "ruta_archivo", nullable = false, length = 300)
    private String rutaArchivo;

    @Column(name = "fecha_registro", nullable = false)
    private LocalDate fechaRegistro = LocalDate.now();
}
