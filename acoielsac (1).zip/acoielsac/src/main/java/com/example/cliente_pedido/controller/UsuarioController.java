package com.example.cliente_pedido.controller;

import com.example.cliente_pedido.model.Persona;
import com.example.cliente_pedido.model.Usuario;
import com.example.cliente_pedido.repository.UsuarioRepository;
import com.example.cliente_pedido.service.PersonaService;
import com.example.cliente_pedido.service.UsuarioService;
import jakarta.servlet.http.HttpSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/usuario")
public class UsuarioController {

    @Autowired private UsuarioService service;
    @Autowired private PersonaService personaService;
    @Autowired private UsuarioRepository usuarioRepository;

    private boolean sinSesion(HttpSession s) { return s.getAttribute("usuarioId") == null; }

    @GetMapping
    public String listar(Model model, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        model.addAttribute("lista", service.readAll());
        return "usuario/lista";
    }

    @GetMapping("/nuevo")
    public String nuevo(Model model, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        model.addAttribute("usuario", new Usuario());
        model.addAttribute("persona", new Persona());
        return "usuario/form";
    }

    @PostMapping("/guardar")
    public String guardar(@ModelAttribute("persona") Persona persona,
                          @ModelAttribute("usuario") Usuario usuario,
                          Model model, RedirectAttributes ra, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        if (usuarioRepository.findByNombreUsuario(usuario.getNombreUsuario()).isPresent()) {
            model.addAttribute("mensajeError", "Ya existe un usuario con ese nombre.");
            model.addAttribute("persona", persona);
            model.addAttribute("usuario", usuario);
            return "usuario/form";
        }
        persona = personaService.create(persona);
        usuario.setPersona(persona);
        if (usuario.getEstadoUsuario() == null) usuario.setEstadoUsuario("ACTIVO");
        service.create(usuario);
        ra.addFlashAttribute("mensajeExito", "Usuario creado correctamente.");
        return "redirect:/usuario";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id, RedirectAttributes ra, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        try { service.delete(id); ra.addFlashAttribute("mensajeExito", "Usuario eliminado."); }
        catch (Exception e) { ra.addFlashAttribute("mensajeError", "No se puede eliminar."); }
        return "redirect:/usuario";
    }
}
