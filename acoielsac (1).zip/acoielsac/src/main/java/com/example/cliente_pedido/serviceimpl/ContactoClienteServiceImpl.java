package com.example.cliente_pedido.serviceimpl;

import com.example.cliente_pedido.model.ContactoCliente;
import com.example.cliente_pedido.repository.ContactoClienteRepository;
import com.example.cliente_pedido.service.ContactoClienteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ContactoClienteServiceImpl implements ContactoClienteService {

    @Autowired
    private ContactoClienteRepository repository;

    @Override
    public ContactoCliente create(ContactoCliente obj) {
        return repository.save(obj);
    }

    @Override
    public ContactoCliente update(ContactoCliente obj) {
        return repository.save(obj);
    }

    @Override
    public Optional<ContactoCliente> read(Long id) {
        return repository.findById(id);
    }

    @Override
    public void delete(Long id) {
        repository.deleteById(id);
    }

    @Override
    public Iterable<ContactoCliente> readAll() {
        return repository.findAll();
    }
}
