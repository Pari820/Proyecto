package com.example.cliente_pedido.controller;

import com.example.cliente_pedido.model.UsoSistema;
import com.example.cliente_pedido.service.UsoSistemaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/uso-sistema")
public class UsoSistemaRestController {

    @Autowired
    private UsoSistemaService service;

    @GetMapping
    public Iterable<UsoSistema> listar() {
        return service.readAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<UsoSistema> buscarPorId(@PathVariable Long id) {
        return service.read(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public UsoSistema crear(@RequestBody UsoSistema obj) {
        return service.create(obj);
    }

    @PutMapping("/{id}")
    public ResponseEntity<UsoSistema> actualizar(@PathVariable Long id, @RequestBody UsoSistema obj) {
        return service.read(id)
                .map(existente -> ResponseEntity.ok(service.update(obj)))
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        if (service.read(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
