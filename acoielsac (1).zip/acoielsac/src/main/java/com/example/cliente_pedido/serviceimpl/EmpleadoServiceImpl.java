package com.example.cliente_pedido.serviceimpl;

import com.example.cliente_pedido.model.Empleado;
import com.example.cliente_pedido.repository.EmpleadoRepository;
import com.example.cliente_pedido.service.EmpleadoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class EmpleadoServiceImpl implements EmpleadoService {

    @Autowired
    private EmpleadoRepository repository;

    @Override
    public Empleado create(Empleado obj) {
        return repository.save(obj);
    }

    @Override
    public Empleado update(Empleado obj) {
        return repository.save(obj);
    }

    @Override
    public Optional<Empleado> read(Long id) {
        return repository.findById(id);
    }

    @Override
    public void delete(Long id) {
        repository.deleteById(id);
    }

    @Override
    public Iterable<Empleado> readAll() {
        return repository.findAll();
    }
}
