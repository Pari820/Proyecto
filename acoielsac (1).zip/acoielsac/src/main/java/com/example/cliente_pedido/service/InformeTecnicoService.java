package com.example.cliente_pedido.service;

import com.example.cliente_pedido.generic.CrudService;
import com.example.cliente_pedido.model.InformeTecnico;

public interface InformeTecnicoService extends CrudService<InformeTecnico, Long> {
}
