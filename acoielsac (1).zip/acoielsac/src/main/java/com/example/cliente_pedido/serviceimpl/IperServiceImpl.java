package com.example.cliente_pedido.serviceimpl;

import com.example.cliente_pedido.model.Iper;
import com.example.cliente_pedido.repository.IperRepository;
import com.example.cliente_pedido.service.IperService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class IperServiceImpl implements IperService {

    @Autowired
    private IperRepository repository;

    @Override
    public Iper create(Iper obj) {
        return repository.save(obj);
    }

    @Override
    public Iper update(Iper obj) {
        return repository.save(obj);
    }

    @Override
    public Optional<Iper> read(Long id) {
        return repository.findById(id);
    }

    @Override
    public void delete(Long id) {
        repository.deleteById(id);
    }

    @Override
    public Iterable<Iper> readAll() {
        return repository.findAll();
    }
}
