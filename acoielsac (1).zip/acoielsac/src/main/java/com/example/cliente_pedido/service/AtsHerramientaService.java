package com.example.cliente_pedido.service;

import com.example.cliente_pedido.generic.CrudService;
import com.example.cliente_pedido.model.AtsHerramienta;

public interface AtsHerramientaService extends CrudService<AtsHerramienta, Long> {
}
