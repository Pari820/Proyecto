package com.example.cliente_pedido.repository;

import com.example.cliente_pedido.model.UsoSistema;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface UsoSistemaRepository extends JpaRepository<UsoSistema, Long> {
}
