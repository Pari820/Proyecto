package com.example.cliente_pedido.service;

import com.example.cliente_pedido.generic.CrudService;
import com.example.cliente_pedido.model.SolicitudServicio;

public interface SolicitudServicioService extends CrudService<SolicitudServicio, Long> {
}
