package com.example.cliente_pedido.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "ROL_ACCESO", uniqueConstraints = @UniqueConstraint(columnNames = {"id_rol", "id_acceso"}))
@Data @NoArgsConstructor @AllArgsConstructor
public class RolAcceso {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_rol_acceso")
    private Long idRolAcceso;

    @ManyToOne
    @JoinColumn(name = "id_rol", nullable = false)
    private Rol rol;

    @ManyToOne
    @JoinColumn(name = "id_acceso", nullable = false)
    private Acceso acceso;

    @Column(name = "permiso_crear", nullable = false, length = 1)
    private String permisoCrear = "N";

    @Column(name = "permiso_leer", nullable = false, length = 1)
    private String permisoLeer = "S";

    @Column(name = "permiso_actualizar", nullable = false, length = 1)
    private String permisoActualizar = "N";

    @Column(name = "permiso_eliminar", nullable = false, length = 1)
    private String permisoEliminar = "N";
}
