package com.example.cliente_pedido.controller;

import com.example.cliente_pedido.model.AtencionServicio;
import com.example.cliente_pedido.service.AtencionServicioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/atencion-servicio")
public class AtencionServicioRestController {

    @Autowired
    private AtencionServicioService service;

    @GetMapping
    public Iterable<AtencionServicio> listar() {
        return service.readAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<AtencionServicio> buscarPorId(@PathVariable Long id) {
        return service.read(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public AtencionServicio crear(@RequestBody AtencionServicio obj) {
        return service.create(obj);
    }

    @PutMapping("/{id}")
    public ResponseEntity<AtencionServicio> actualizar(@PathVariable Long id, @RequestBody AtencionServicio obj) {
        return service.read(id)
                .map(existente -> ResponseEntity.ok(service.update(obj)))
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        if (service.read(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
