package com.example.cliente_pedido.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

@Entity
@Table(name = "PROCEDIMIENTO_TRABAJO")
@Data @NoArgsConstructor @AllArgsConstructor
public class ProcedimientoTrabajo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_procedimiento")
    private Long idProcedimiento;

    @OneToOne
    @JoinColumn(name = "id_orden_trabajo", nullable = false, unique = true)
    private OrdenTrabajo ordenTrabajo;

    @Column(name = "fecha_registro", nullable = false)
    private LocalDate fechaRegistro = LocalDate.now();

    @Column(name = "archivo_procedimiento", length = 300)
    private String archivoProcedimiento;

    @Column(name = "observaciones", length = 500)
    private String observaciones;

    @Column(name = "estado_aprobacion_cliente", nullable = false, length = 30)
    private String estadoAprobacionCliente = "PENDIENTE";
}
