package com.example.cliente_pedido.serviceimpl;

import com.example.cliente_pedido.model.DetalleMaterialServicio;
import com.example.cliente_pedido.repository.DetalleMaterialServicioRepository;
import com.example.cliente_pedido.service.DetalleMaterialServicioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class DetalleMaterialServicioServiceImpl implements DetalleMaterialServicioService {

    @Autowired
    private DetalleMaterialServicioRepository repository;

    @Override
    public DetalleMaterialServicio create(DetalleMaterialServicio obj) {
        return repository.save(obj);
    }

    @Override
    public DetalleMaterialServicio update(DetalleMaterialServicio obj) {
        return repository.save(obj);
    }

    @Override
    public Optional<DetalleMaterialServicio> read(Long id) {
        return repository.findById(id);
    }

    @Override
    public void delete(Long id) {
        repository.deleteById(id);
    }

    @Override
    public Iterable<DetalleMaterialServicio> readAll() {
        return repository.findAll();
    }
}
