package com.example.cliente_pedido.serviceimpl;

import com.example.cliente_pedido.model.Usuario;
import com.example.cliente_pedido.repository.UsuarioRepository;
import com.example.cliente_pedido.service.UsuarioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class UsuarioServiceImpl implements UsuarioService {

    @Autowired
    private UsuarioRepository repository;

    @Override
    public Usuario create(Usuario obj) {
        return repository.save(obj);
    }

    @Override
    public Usuario update(Usuario obj) {
        return repository.save(obj);
    }

    @Override
    public Optional<Usuario> read(Long id) {
        return repository.findById(id);
    }

    @Override
    public void delete(Long id) {
        repository.deleteById(id);
    }

    @Override
    public Iterable<Usuario> readAll() {
        return repository.findAll();
    }
}
