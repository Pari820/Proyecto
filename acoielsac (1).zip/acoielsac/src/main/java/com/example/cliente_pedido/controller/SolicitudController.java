package com.example.cliente_pedido.controller;

import com.example.cliente_pedido.model.SolicitudServicio;
import com.example.cliente_pedido.service.ClienteService;
import com.example.cliente_pedido.service.SolicitudServicioService;
import com.example.cliente_pedido.service.TipoServicioService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import java.time.LocalDate;

@Controller
@RequestMapping("/solicitud")
public class SolicitudController {

    @Autowired private SolicitudServicioService service;
    @Autowired private ClienteService clienteService;
    @Autowired private TipoServicioService tipoServicioService;

    private boolean sinSesion(HttpSession s) { return s.getAttribute("usuarioId") == null; }

    @GetMapping
    public String listar(Model model, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        model.addAttribute("lista", service.readAll());
        return "solicitud/lista";
    }

    @GetMapping("/nuevo")
    public String nuevo(Model model, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        SolicitudServicio obj = new SolicitudServicio();
        obj.setEstadoSolicitud("PENDIENTE");
        obj.setFechaRecepcion(LocalDate.now());
        model.addAttribute("obj", obj);
        model.addAttribute("clientes", clienteService.readAll());
        model.addAttribute("tiposServicio", tipoServicioService.readAll());
        return "solicitud/form";
    }

    @PostMapping("/guardar")
    public String guardar(@Valid @ModelAttribute("obj") SolicitudServicio obj,
                          BindingResult result, Model model,
                          RedirectAttributes ra, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        if (result.hasErrors()) {
            model.addAttribute("clientes", clienteService.readAll());
            model.addAttribute("tiposServicio", tipoServicioService.readAll());
            return "solicitud/form";
        }
        if (obj.getEstadoSolicitud() == null || obj.getEstadoSolicitud().isEmpty())
            obj.setEstadoSolicitud("PENDIENTE");
        service.create(obj);
        ra.addFlashAttribute("mensajeExito", "Solicitud registrada correctamente.");
        return "redirect:/solicitud";
    }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Long id, Model model, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        SolicitudServicio obj = service.read(id).orElse(null);
        if (obj == null) return "redirect:/solicitud";
        model.addAttribute("obj", obj);
        model.addAttribute("clientes", clienteService.readAll());
        model.addAttribute("tiposServicio", tipoServicioService.readAll());
        return "solicitud/form";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id, RedirectAttributes ra, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        try {
            service.delete(id);
            ra.addFlashAttribute("mensajeExito", "Solicitud eliminada.");
        } catch (Exception e) {
            ra.addFlashAttribute("mensajeError", "No se puede eliminar. Tiene registros asociados.");
        }
        return "redirect:/solicitud";
    }
}
