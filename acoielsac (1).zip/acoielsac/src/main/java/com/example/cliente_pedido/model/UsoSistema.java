package com.example.cliente_pedido.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "USO_SISTEMA")
@Data @NoArgsConstructor @AllArgsConstructor
public class UsoSistema {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_uso")
    private Long idUso;

    @ManyToOne
    @JoinColumn(name = "id_usuario", nullable = false)
    private Usuario usuario;

    @Column(name = "fecha_hora", nullable = false)
    private LocalDateTime fechaHora = LocalDateTime.now();

    @NotBlank
    @Column(name = "accion_realizada", nullable = false, length = 150)
    private String accionRealizada;

    @Column(name = "modulo", length = 100)
    private String modulo;

    @Column(name = "descripcion", length = 300)
    private String descripcion;
}
