package com.example.cliente_pedido.controller;

import com.example.cliente_pedido.model.AtsHerramienta;
import com.example.cliente_pedido.service.AtsHerramientaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/ats-herramienta")
public class AtsHerramientaRestController {

    @Autowired
    private AtsHerramientaService service;

    @GetMapping
    public Iterable<AtsHerramienta> listar() {
        return service.readAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<AtsHerramienta> buscarPorId(@PathVariable Long id) {
        return service.read(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public AtsHerramienta crear(@RequestBody AtsHerramienta obj) {
        return service.create(obj);
    }

    @PutMapping("/{id}")
    public ResponseEntity<AtsHerramienta> actualizar(@PathVariable Long id, @RequestBody AtsHerramienta obj) {
        return service.read(id)
                .map(existente -> ResponseEntity.ok(service.update(obj)))
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        if (service.read(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
