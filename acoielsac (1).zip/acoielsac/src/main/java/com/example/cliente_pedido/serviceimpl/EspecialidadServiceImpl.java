package com.example.cliente_pedido.serviceimpl;

import com.example.cliente_pedido.model.Especialidad;
import com.example.cliente_pedido.repository.EspecialidadRepository;
import com.example.cliente_pedido.service.EspecialidadService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class EspecialidadServiceImpl implements EspecialidadService {

    @Autowired
    private EspecialidadRepository repository;

    @Override
    public Especialidad create(Especialidad obj) {
        return repository.save(obj);
    }

    @Override
    public Especialidad update(Especialidad obj) {
        return repository.save(obj);
    }

    @Override
    public Optional<Especialidad> read(Long id) {
        return repository.findById(id);
    }

    @Override
    public void delete(Long id) {
        repository.deleteById(id);
    }

    @Override
    public Iterable<Especialidad> readAll() {
        return repository.findAll();
    }
}
