package com.example.cliente_pedido.serviceimpl;

import com.example.cliente_pedido.model.Epp;
import com.example.cliente_pedido.repository.EppRepository;
import com.example.cliente_pedido.service.EppService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class EppServiceImpl implements EppService {

    @Autowired
    private EppRepository repository;

    @Override
    public Epp create(Epp obj) {
        return repository.save(obj);
    }

    @Override
    public Epp update(Epp obj) {
        return repository.save(obj);
    }

    @Override
    public Optional<Epp> read(Long id) {
        return repository.findById(id);
    }

    @Override
    public void delete(Long id) {
        repository.deleteById(id);
    }

    @Override
    public Iterable<Epp> readAll() {
        return repository.findAll();
    }
}
