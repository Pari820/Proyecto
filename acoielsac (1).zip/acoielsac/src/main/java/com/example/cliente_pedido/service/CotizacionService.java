package com.example.cliente_pedido.service;

import com.example.cliente_pedido.generic.CrudService;
import com.example.cliente_pedido.model.Cotizacion;

public interface CotizacionService extends CrudService<Cotizacion, Long> {
}
