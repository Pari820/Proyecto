package com.example.cliente_pedido.serviceimpl;

import com.example.cliente_pedido.model.ProcedimientoTrabajo;
import com.example.cliente_pedido.repository.ProcedimientoTrabajoRepository;
import com.example.cliente_pedido.service.ProcedimientoTrabajoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ProcedimientoTrabajoServiceImpl implements ProcedimientoTrabajoService {

    @Autowired
    private ProcedimientoTrabajoRepository repository;

    @Override
    public ProcedimientoTrabajo create(ProcedimientoTrabajo obj) {
        return repository.save(obj);
    }

    @Override
    public ProcedimientoTrabajo update(ProcedimientoTrabajo obj) {
        return repository.save(obj);
    }

    @Override
    public Optional<ProcedimientoTrabajo> read(Long id) {
        return repository.findById(id);
    }

    @Override
    public void delete(Long id) {
        repository.deleteById(id);
    }

    @Override
    public Iterable<ProcedimientoTrabajo> readAll() {
        return repository.findAll();
    }
}
