package com.example.cliente_pedido.service;

import com.example.cliente_pedido.generic.CrudService;
import com.example.cliente_pedido.model.OrdenCompra;

public interface OrdenCompraService extends CrudService<OrdenCompra, Long> {
}
