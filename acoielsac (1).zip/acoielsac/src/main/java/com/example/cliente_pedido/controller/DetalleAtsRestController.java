package com.example.cliente_pedido.controller;

import com.example.cliente_pedido.model.DetalleAts;
import com.example.cliente_pedido.service.DetalleAtsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/detalle-ats")
public class DetalleAtsRestController {

    @Autowired
    private DetalleAtsService service;

    @GetMapping
    public Iterable<DetalleAts> listar() {
        return service.readAll();
    }

    @GetMapping("/{id}")
    public ResponseEntity<DetalleAts> buscarPorId(@PathVariable Long id) {
        return service.read(id)
                .map(ResponseEntity::ok)
                .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public DetalleAts crear(@RequestBody DetalleAts obj) {
        return service.create(obj);
    }

    @PutMapping("/{id}")
    public ResponseEntity<DetalleAts> actualizar(@PathVariable Long id, @RequestBody DetalleAts obj) {
        return service.read(id)
                .map(existente -> ResponseEntity.ok(service.update(obj)))
                .orElse(ResponseEntity.notFound().build());
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Long id) {
        if (service.read(id).isEmpty()) {
            return ResponseEntity.notFound().build();
        }
        service.delete(id);
        return ResponseEntity.noContent().build();
    }
}
