package com.example.cliente_pedido.service;

import com.example.cliente_pedido.generic.CrudService;
import com.example.cliente_pedido.model.Especialidad;

public interface EspecialidadService extends CrudService<Especialidad, Long> {
}
