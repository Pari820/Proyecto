package com.example.cliente_pedido.serviceimpl;

import com.example.cliente_pedido.model.Acceso;
import com.example.cliente_pedido.repository.AccesoRepository;
import com.example.cliente_pedido.service.AccesoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AccesoServiceImpl implements AccesoService {

    @Autowired
    private AccesoRepository repository;

    @Override
    public Acceso create(Acceso obj) {
        return repository.save(obj);
    }

    @Override
    public Acceso update(Acceso obj) {
        return repository.save(obj);
    }

    @Override
    public Optional<Acceso> read(Long id) {
        return repository.findById(id);
    }

    @Override
    public void delete(Long id) {
        repository.deleteById(id);
    }

    @Override
    public Iterable<Acceso> readAll() {
        return repository.findAll();
    }
}
