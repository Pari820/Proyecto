package com.example.cliente_pedido.service;

import com.example.cliente_pedido.generic.CrudService;
import com.example.cliente_pedido.model.Persona;

public interface PersonaService extends CrudService<Persona, Long> {
}
