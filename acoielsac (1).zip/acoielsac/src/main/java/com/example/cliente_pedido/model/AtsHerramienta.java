package com.example.cliente_pedido.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "ATS_HERRAMIENTA", uniqueConstraints = @UniqueConstraint(columnNames = {"id_ats", "id_herramienta"}))
@Data @NoArgsConstructor @AllArgsConstructor
public class AtsHerramienta {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_ats_herramienta")
    private Long idAtsHerramienta;

    @ManyToOne
    @JoinColumn(name = "id_ats", nullable = false)
    private Ats ats;

    @ManyToOne
    @JoinColumn(name = "id_herramienta", nullable = false)
    private HerramientaEquipo herramientaEquipo;
}
