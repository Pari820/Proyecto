package com.example.cliente_pedido.serviceimpl;

import com.example.cliente_pedido.model.InformeTecnico;
import com.example.cliente_pedido.repository.InformeTecnicoRepository;
import com.example.cliente_pedido.service.InformeTecnicoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class InformeTecnicoServiceImpl implements InformeTecnicoService {

    @Autowired
    private InformeTecnicoRepository repository;

    @Override
    public InformeTecnico create(InformeTecnico obj) {
        return repository.save(obj);
    }

    @Override
    public InformeTecnico update(InformeTecnico obj) {
        return repository.save(obj);
    }

    @Override
    public Optional<InformeTecnico> read(Long id) {
        return repository.findById(id);
    }

    @Override
    public void delete(Long id) {
        repository.deleteById(id);
    }

    @Override
    public Iterable<InformeTecnico> readAll() {
        return repository.findAll();
    }
}
