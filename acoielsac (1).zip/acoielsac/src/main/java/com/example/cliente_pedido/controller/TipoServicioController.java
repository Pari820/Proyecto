package com.example.cliente_pedido.controller;

import com.example.cliente_pedido.model.TipoServicio;
import com.example.cliente_pedido.service.TipoServicioService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/tiposervicio")
public class TipoServicioController {

    @Autowired private TipoServicioService service;

    private boolean sinSesion(HttpSession s) { return s.getAttribute("usuarioId") == null; }

    @GetMapping
    public String listar(Model model, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        model.addAttribute("lista", service.readAll());
        return "tiposervicio/lista";
    }

    @GetMapping("/nuevo")
    public String nuevo(Model model, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        model.addAttribute("obj", new TipoServicio());
        return "tiposervicio/form";
    }

    @PostMapping("/guardar")
    public String guardar(@Valid @ModelAttribute("obj") TipoServicio obj,
                          BindingResult result, RedirectAttributes ra, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        if (result.hasErrors()) return "tiposervicio/form";
        service.create(obj);
        ra.addFlashAttribute("mensajeExito", "Tipo de servicio guardado correctamente.");
        return "redirect:/tiposervicio";
    }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Long id, Model model, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        TipoServicio obj = service.read(id).orElse(null);
        if (obj == null) return "redirect:/tiposervicio";
        model.addAttribute("obj", obj);
        return "tiposervicio/form";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id, RedirectAttributes ra, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        try {
            service.delete(id);
            ra.addFlashAttribute("mensajeExito", "Tipo de servicio eliminado.");
        } catch (Exception e) {
            ra.addFlashAttribute("mensajeError", "No se puede eliminar. Tiene registros asociados.");
        }
        return "redirect:/tiposervicio";
    }
}
