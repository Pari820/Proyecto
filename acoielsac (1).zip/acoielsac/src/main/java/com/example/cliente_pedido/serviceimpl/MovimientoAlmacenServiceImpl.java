package com.example.cliente_pedido.serviceimpl;

import com.example.cliente_pedido.model.MovimientoAlmacen;
import com.example.cliente_pedido.repository.MovimientoAlmacenRepository;
import com.example.cliente_pedido.service.MovimientoAlmacenService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class MovimientoAlmacenServiceImpl implements MovimientoAlmacenService {

    @Autowired
    private MovimientoAlmacenRepository repository;

    @Override
    public MovimientoAlmacen create(MovimientoAlmacen obj) {
        return repository.save(obj);
    }

    @Override
    public MovimientoAlmacen update(MovimientoAlmacen obj) {
        return repository.save(obj);
    }

    @Override
    public Optional<MovimientoAlmacen> read(Long id) {
        return repository.findById(id);
    }

    @Override
    public void delete(Long id) {
        repository.deleteById(id);
    }

    @Override
    public Iterable<MovimientoAlmacen> readAll() {
        return repository.findAll();
    }
}
