package com.example.cliente_pedido.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;
import java.time.LocalDate;

@Entity
@Table(name = "SOLICITUD_SERVICIO")
@Data @NoArgsConstructor @AllArgsConstructor
public class SolicitudServicio {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_solicitud")
    private Long idSolicitud;

    @ManyToOne
    @JoinColumn(name = "id_cliente", nullable = false)
    private Cliente cliente;

    @ManyToOne
    @JoinColumn(name = "id_tipo_servicio", nullable = false)
    private TipoServicio tipoServicio;

    @Column(name = "fecha_recepcion", nullable = false)
    private LocalDate fechaRecepcion = LocalDate.now();

    @NotBlank
    @Column(name = "descripcion_trabajo", nullable = false, length = 500)
    private String descripcionTrabajo;

    @Column(name = "observaciones_iniciales", length = 500)
    private String observacionesIniciales;

    @Column(name = "estado_solicitud", nullable = false, length = 30)
    private String estadoSolicitud = "PENDIENTE";
}
