package com.example.cliente_pedido.repository;

import com.example.cliente_pedido.model.ProcedimientoTrabajo;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ProcedimientoTrabajoRepository extends JpaRepository<ProcedimientoTrabajo, Long> {
}
