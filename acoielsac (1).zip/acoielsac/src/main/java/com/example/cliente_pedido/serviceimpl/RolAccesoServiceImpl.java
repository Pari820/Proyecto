package com.example.cliente_pedido.serviceimpl;

import com.example.cliente_pedido.model.RolAcceso;
import com.example.cliente_pedido.repository.RolAccesoRepository;
import com.example.cliente_pedido.service.RolAccesoService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class RolAccesoServiceImpl implements RolAccesoService {

    @Autowired
    private RolAccesoRepository repository;

    @Override
    public RolAcceso create(RolAcceso obj) {
        return repository.save(obj);
    }

    @Override
    public RolAcceso update(RolAcceso obj) {
        return repository.save(obj);
    }

    @Override
    public Optional<RolAcceso> read(Long id) {
        return repository.findById(id);
    }

    @Override
    public void delete(Long id) {
        repository.deleteById(id);
    }

    @Override
    public Iterable<RolAcceso> readAll() {
        return repository.findAll();
    }
}
