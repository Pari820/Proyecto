package com.example.cliente_pedido.model;

import jakarta.persistence.*;
import lombok.*;
import java.time.LocalDate;

@Entity
@Table(name = "ATS")
@Data @NoArgsConstructor @AllArgsConstructor
public class Ats {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_ats")
    private Long idAts;

    @OneToOne
    @JoinColumn(name = "id_orden_trabajo", nullable = false, unique = true)
    private OrdenTrabajo ordenTrabajo;

    @Column(name = "fecha_elaboracion", nullable = false)
    private LocalDate fechaElaboracion = LocalDate.now();

    @Column(name = "condiciones_area", length = 700)
    private String condicionesArea;

    @Column(name = "estado_ats", nullable = false, length = 30)
    private String estadoAts = "ELABORADO";

    @Column(name = "fecha_aprobacion")
    private LocalDate fechaAprobacion;

    @Column(name = "supervisor_cliente_firma", length = 150)
    private String supervisorClienteFirma;

    @Column(name = "ssoma_cliente_aprueba", length = 150)
    private String ssomaClienteAprueba;
}
