package com.example.cliente_pedido.repository;

import com.example.cliente_pedido.model.Ats;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AtsRepository extends JpaRepository<Ats, Long> {
}
