package com.example.cliente_pedido.serviceimpl;

import com.example.cliente_pedido.model.Cotizacion;
import com.example.cliente_pedido.repository.CotizacionRepository;
import com.example.cliente_pedido.service.CotizacionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class CotizacionServiceImpl implements CotizacionService {

    @Autowired
    private CotizacionRepository repository;

    @Override
    public Cotizacion create(Cotizacion obj) {
        return repository.save(obj);
    }

    @Override
    public Cotizacion update(Cotizacion obj) {
        return repository.save(obj);
    }

    @Override
    public Optional<Cotizacion> read(Long id) {
        return repository.findById(id);
    }

    @Override
    public void delete(Long id) {
        repository.deleteById(id);
    }

    @Override
    public Iterable<Cotizacion> readAll() {
        return repository.findAll();
    }
}
