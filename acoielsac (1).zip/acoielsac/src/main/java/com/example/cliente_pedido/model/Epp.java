package com.example.cliente_pedido.model;

import jakarta.persistence.*;
import jakarta.validation.constraints.NotBlank;
import lombok.*;

@Entity
@Table(name = "EPP")
@Data @NoArgsConstructor @AllArgsConstructor
public class Epp {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_epp")
    private Long idEpp;

    @NotBlank
    @Column(name = "nombre_epp", nullable = false, length = 120, unique = true)
    private String nombreEpp;

    @Column(name = "descripcion", length = 250)
    private String descripcion;
}
