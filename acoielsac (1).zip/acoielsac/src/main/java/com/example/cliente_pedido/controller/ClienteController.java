package com.example.cliente_pedido.controller;

import com.example.cliente_pedido.model.Cliente;
import com.example.cliente_pedido.repository.ClienteRepository;
import com.example.cliente_pedido.service.ClienteService;
import jakarta.servlet.http.HttpSession;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/cliente")
public class ClienteController {

    @Autowired private ClienteService service;
    @Autowired private ClienteRepository clienteRepository;

    private boolean sinSesion(HttpSession s) {
        return s.getAttribute("usuarioId") == null;
    }

    @GetMapping
    public String listar(Model model, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        model.addAttribute("clientes", service.readAll());
        return "cliente/lista";
    }

    @GetMapping("/nuevo")
    public String nuevo(Model model, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        model.addAttribute("cliente", new Cliente());
        return "cliente/form";
    }

    @PostMapping("/guardar")
    public String guardar(@Valid @ModelAttribute Cliente cliente,
                          BindingResult result,
                          RedirectAttributes ra,
                          HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        if (result.hasErrors()) return "cliente/form";

        // Validar RUC único
        if (cliente.getIdCliente() == null && clienteRepository.existsByRuc(cliente.getRuc())) {
            result.rejectValue("ruc", "error.ruc", "Ya existe un cliente con ese RUC.");
            return "cliente/form";
        }

        service.create(cliente);
        ra.addFlashAttribute("mensajeExito", "Cliente guardado correctamente.");
        return "redirect:/cliente";
    }

    @GetMapping("/editar/{id}")
    public String editar(@PathVariable Long id, Model model, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        Cliente c = service.read(id).orElse(null);
        if (c == null) return "redirect:/cliente";
        model.addAttribute("cliente", c);
        return "cliente/form";
    }

    @GetMapping("/eliminar/{id}")
    public String eliminar(@PathVariable Long id, RedirectAttributes ra, HttpSession session) {
        if (sinSesion(session)) return "redirect:/login";
        try {
            service.delete(id);
            ra.addFlashAttribute("mensajeExito", "Cliente eliminado.");
        } catch (Exception e) {
            ra.addFlashAttribute("mensajeError", "No se puede eliminar. Tiene registros asociados.");
        }
        return "redirect:/cliente";
    }
}
