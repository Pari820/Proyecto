package com.example.cliente_pedido.serviceimpl;

import com.example.cliente_pedido.model.TipoServicio;
import com.example.cliente_pedido.repository.TipoServicioRepository;
import com.example.cliente_pedido.service.TipoServicioService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class TipoServicioServiceImpl implements TipoServicioService {

    @Autowired
    private TipoServicioRepository repository;

    @Override
    public TipoServicio create(TipoServicio obj) {
        return repository.save(obj);
    }

    @Override
    public TipoServicio update(TipoServicio obj) {
        return repository.save(obj);
    }

    @Override
    public Optional<TipoServicio> read(Long id) {
        return repository.findById(id);
    }

    @Override
    public void delete(Long id) {
        repository.deleteById(id);
    }

    @Override
    public Iterable<TipoServicio> readAll() {
        return repository.findAll();
    }
}
